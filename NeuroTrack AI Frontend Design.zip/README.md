
  # NeuroDetect AI Frontend Design

  This is a code bundle for NeuroDetect AI Frontend Design. The original project is available at https://www.figma.com/design/5o1PMRyQbkXJN19hJsUqe5/NeuroDetect-AI-Frontend-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  