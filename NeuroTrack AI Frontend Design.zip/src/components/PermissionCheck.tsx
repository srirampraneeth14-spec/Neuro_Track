import { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

interface PermissionCheckProps {
  type: 'microphone' | 'camera';
}

export function PermissionCheck({ type }: PermissionCheckProps) {
  const [status, setStatus] = useState<'granted' | 'denied' | 'prompt' | 'unknown'>('unknown');

  useEffect(() => {
    checkPermission();
  }, [type]);

  const checkPermission = async () => {
    try {
      const result = await navigator.permissions.query({
        name: type as PermissionName,
      });
      setStatus(result.state);

      // Listen for permission changes
      result.addEventListener('change', () => {
        setStatus(result.state);
      });
    } catch (error) {
      // Permissions API not supported, default to unknown
      setStatus('unknown');
    }
  };

  if (status === 'unknown' || status === 'prompt') {
    return null;
  }

  if (status === 'denied') {
    return (
      <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
        <AlertCircle className="w-4 h-4 flex-shrink-0" />
        <span>
          {type === 'microphone' ? 'Microphone' : 'Camera'} access denied.
          Please enable it in your browser settings.
        </span>
      </div>
    );
  }

  if (status === 'granted') {
    return (
      <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 text-sm">
        <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
        <span>
          {type === 'microphone' ? 'Microphone' : 'Camera'} access granted
        </span>
      </div>
    );
  }

  return null;
}
