import { useState, useRef, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import {
  Mic,
  MicOff,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Volume2,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion } from 'motion/react';
import { PermissionCheck } from './PermissionCheck';

interface VoiceTestProps {
  onComplete: (score: number) => void;
}

export function VoiceTest({ onComplete }: VoiceTestProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [result, setResult] = useState<{
    score: number;
    metrics: {
      clarity: number;
      pitch: number;
      rhythm: number;
      tremor: number;
    };
  } | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<number | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop();
      }
    };
  }, [isRecording]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        setAudioUrl(url);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      timerRef.current = window.setInterval(() => {
        setRecordingTime((prev) => {
          if (prev >= 30) {
            stopRecording();
            return prev;
          }
          return prev + 1;
        });
      }, 1000);

      toast.success('Recording started');
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotAllowedError') {
        toast.error('Microphone access denied. Please enable it in your browser settings.');
      } else {
        toast.error('Could not access microphone. Please check your device settings.');
      }
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      toast.info('Recording stopped');
    }
  };

  const togglePlayback = () => {
    if (!audioRef.current) {
      if (audioUrl) {
        audioRef.current = new Audio(audioUrl);
        audioRef.current.onended = () => setIsPlaying(false);
      }
    }

    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const analyzeRecording = async () => {
    setIsAnalyzing(true);
    setAnalysisProgress(0);

    // Simulate AI analysis with progress
    for (let i = 0; i <= 100; i += 5) {
      await new Promise((resolve) => setTimeout(resolve, 100));
      setAnalysisProgress(i);
    }

    // Generate mock analysis results
    const clarity = Math.floor(Math.random() * 20) + 80;
    const pitch = Math.floor(Math.random() * 20) + 75;
    const rhythm = Math.floor(Math.random() * 25) + 70;
    const tremor = Math.floor(Math.random() * 20) + 75;
    const averageScore = Math.floor((clarity + pitch + rhythm + tremor) / 4);

    setResult({
      score: averageScore,
      metrics: { clarity, pitch, rhythm, tremor },
    });

    setIsAnalyzing(false);
    toast.success('Analysis complete!');
  };

  const reset = () => {
    setRecordingTime(0);
    setResult(null);
    setAudioUrl(null);
    setIsPlaying(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    chunksRef.current = [];
  };

  const saveResults = () => {
    if (result) {
      onComplete(result.score);
      toast.success('Voice analysis saved!');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h2 className="text-teal-600 mb-2">Voice Analysis</h2>
        <p className="text-gray-600">
          Record your voice to analyze patterns that may indicate neurological
          changes
        </p>
      </div>

      {/* Permission Check */}
      <PermissionCheck type="microphone" />

      {/* Recording Card */}
      <Card className="p-8 shadow-lg">
        <div className="text-center space-y-6">
          <div className="flex justify-center">
            <motion.div
              className={`w-32 h-32 rounded-full flex items-center justify-center ${
                isRecording
                  ? 'bg-red-500'
                  : audioUrl
                  ? 'bg-green-500'
                  : 'bg-teal-500'
              }`}
              animate={
                isRecording
                  ? {
                      scale: [1, 1.1, 1],
                      opacity: [1, 0.8, 1],
                    }
                  : {}
              }
              transition={{
                duration: 1.5,
                repeat: isRecording ? Infinity : 0,
              }}
            >
              {isRecording ? (
                <MicOff className="w-16 h-16 text-white" />
              ) : audioUrl ? (
                <CheckCircle2 className="w-16 h-16 text-white" />
              ) : (
                <Mic className="w-16 h-16 text-white" />
              )}
            </motion.div>
          </div>

          <div>
            <div className="text-4xl mb-2">
              {Math.floor(recordingTime / 60)}:
              {(recordingTime % 60).toString().padStart(2, '0')}
            </div>
            <p className="text-gray-600">
              {isRecording
                ? 'Recording in progress...'
                : audioUrl
                ? 'Recording complete'
                : 'Ready to record'}
            </p>
          </div>

          <div className="flex justify-center gap-3">
            {!isRecording && !audioUrl && (
              <Button
                onClick={startRecording}
                size="lg"
                className="bg-teal-600 hover:bg-teal-700"
              >
                <Mic className="w-5 h-5 mr-2" />
                Start Recording
              </Button>
            )}

            {isRecording && (
              <Button
                onClick={stopRecording}
                size="lg"
                variant="destructive"
              >
                <MicOff className="w-5 h-5 mr-2" />
                Stop Recording
              </Button>
            )}

            {audioUrl && !result && (
              <>
                <Button onClick={togglePlayback} variant="outline" size="lg">
                  {isPlaying ? (
                    <Pause className="w-5 h-5 mr-2" />
                  ) : (
                    <Play className="w-5 h-5 mr-2" />
                  )}
                  {isPlaying ? 'Pause' : 'Play'}
                </Button>
                <Button onClick={reset} variant="outline" size="lg">
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Record Again
                </Button>
                <Button
                  onClick={analyzeRecording}
                  size="lg"
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  Analyze Recording
                </Button>
              </>
            )}
          </div>

          {isAnalyzing && (
            <div className="space-y-3">
              <p className="text-gray-600">Analyzing voice patterns...</p>
              <Progress value={analysisProgress} className="h-2" />
              <p className="text-sm text-gray-500">{analysisProgress}%</p>
            </div>
          )}
        </div>
      </Card>

      {/* Instructions */}
      {!audioUrl && !result && (
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="text-blue-800 mb-3">Recording Instructions</h3>
          <ul className="space-y-2 text-blue-700">
            <li className="flex items-start gap-2">
              <Volume2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Speak clearly for at least 15-30 seconds in a quiet environment
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Volume2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Read a passage, describe your day, or count from 1 to 20
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Volume2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Maintain consistent volume and speak at your natural pace
              </span>
            </li>
          </ul>
        </Card>
      )}

      {/* Results */}
      {result && (
        <Card className="p-6 shadow-lg space-y-6">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-teal-100 rounded-full mb-4">
              <span className="text-3xl text-teal-600">{result.score}</span>
            </div>
            <h3 className="mb-2">Voice Health Score</h3>
            <p className="text-gray-600">
              Your voice patterns are within{' '}
              {result.score >= 80
                ? 'normal'
                : result.score >= 60
                ? 'acceptable'
                : 'concerning'}{' '}
              range
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Voice Clarity</span>
                <span className="text-teal-600">{result.metrics.clarity}%</span>
              </div>
              <Progress value={result.metrics.clarity} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Pitch Stability</span>
                <span className="text-teal-600">{result.metrics.pitch}%</span>
              </div>
              <Progress value={result.metrics.pitch} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Speech Rhythm</span>
                <span className="text-teal-600">{result.metrics.rhythm}%</span>
              </div>
              <Progress value={result.metrics.rhythm} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Tremor Detection</span>
                <span className="text-teal-600">{result.metrics.tremor}%</span>
              </div>
              <Progress value={result.metrics.tremor} className="h-2" />
            </div>
          </div>

          <div className="flex gap-3">
            <Button onClick={reset} variant="outline" className="flex-1">
              <RotateCcw className="w-4 h-4 mr-2" />
              Test Again
            </Button>
            <Button
              onClick={saveResults}
              className="flex-1 bg-teal-600 hover:bg-teal-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Save Results
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
