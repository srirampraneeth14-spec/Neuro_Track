import { UserData } from '../App';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import {
  Stethoscope,
  User,
  Activity,
  TrendingUp,
  AlertTriangle,
  Download,
  FileText,
  Calendar,
  BarChart3,
} from 'lucide-react';
import { TrendChart } from './TrendChart';

interface DoctorViewProps {
  userData: UserData;
}

export function DoctorView({ userData }: DoctorViewProps) {
  const latestReport =
    userData.reports.length > 0
      ? userData.reports[userData.reports.length - 1]
      : null;

  const getRiskColor = (risk: 'low' | 'moderate' | 'high' | null) => {
    if (!risk) return 'text-gray-600';
    if (risk === 'low') return 'text-green-600';
    if (risk === 'moderate') return 'text-yellow-600';
    return 'text-red-600';
  };

  const getRiskBadge = (risk: 'low' | 'moderate' | 'high') => {
    const variants = {
      low: 'bg-green-100 text-green-700 border-green-200',
      moderate: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      high: 'bg-red-100 text-red-700 border-red-200',
    };

    return (
      <Badge variant="outline" className={variants[risk]}>
        {risk.charAt(0).toUpperCase() + risk.slice(1)} Risk
      </Badge>
    );
  };

  const calculateAverage = (scores: (number | null)[]) => {
    const validScores = scores.filter((s) => s !== null) as number[];
    if (validScores.length === 0) return null;
    return Math.round(
      validScores.reduce((a, b) => a + b, 0) / validScores.length
    );
  };

  const voiceAvg = calculateAverage(
    userData.reports.map((r) => r.voiceScore)
  );
  const faceAvg = calculateAverage(userData.reports.map((r) => r.faceScore));
  const typingAvg = calculateAverage(
    userData.reports.map((r) => r.typingScore)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-500 rounded-2xl p-6 md:p-8 text-white shadow-lg">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <Stethoscope className="w-8 h-8" />
              <h2 className="text-white">Doctor Dashboard</h2>
            </div>
            <p className="opacity-90">
              Comprehensive view of patient neurological health metrics
            </p>
          </div>
          <Button
            variant="outline"
            className="bg-white/20 border-white/40 text-white hover:bg-white/30"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Patient Overview */}
      <Card className="p-6 shadow-lg">
        <div className="flex items-start gap-4 mb-6">
          <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="mb-1">Patient Overview</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              <div>
                <p className="text-sm text-gray-600">Total Assessments</p>
                <p className="text-2xl text-blue-600">
                  {userData.reports.length}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Last Assessment</p>
                <p className="text-2xl text-blue-600">
                  {userData.lastScanDate
                    ? new Date(userData.lastScanDate).toLocaleDateString(
                        'en-US',
                        { month: 'short', day: 'numeric' }
                      )
                    : 'N/A'}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Current Risk Level</p>
                <p
                  className={`text-2xl ${getRiskColor(userData.combinedRisk)} capitalize`}
                >
                  {userData.combinedRisk || 'N/A'}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Monitoring Period</p>
                <p className="text-2xl text-blue-600">
                  {userData.reports.length > 0
                    ? Math.ceil(
                        (Date.now() -
                          new Date(userData.reports[0].date).getTime()) /
                          (1000 * 60 * 60 * 24)
                      )
                    : 0}{' '}
                  days
                </p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Clinical Metrics */}
      <Tabs defaultValue="summary" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="summary">Summary</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="summary" className="space-y-6">
          {/* Current Status */}
          {latestReport ? (
            <>
              <Card className="p-6 shadow-lg">
                <div className="flex items-center justify-between mb-6">
                  <h3>Current Assessment</h3>
                  {getRiskBadge(latestReport.riskLevel)}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-teal-600" />
                      <h4>Voice Analysis</h4>
                    </div>
                    <div className="text-3xl text-teal-600">
                      {latestReport.voiceScore}
                      <span className="text-lg text-gray-500">/100</span>
                    </div>
                    <Progress
                      value={latestReport.voiceScore}
                      className="h-2"
                    />
                    <p className="text-sm text-gray-600">
                      Speech patterns, clarity, tremor detection
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-blue-600" />
                      <h4>Facial Analysis</h4>
                    </div>
                    <div className="text-3xl text-blue-600">
                      {latestReport.faceScore}
                      <span className="text-lg text-gray-500">/100</span>
                    </div>
                    <Progress value={latestReport.faceScore} className="h-2" />
                    <p className="text-sm text-gray-600">
                      Expressions, symmetry, micro-movements
                    </p>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-purple-600" />
                      <h4>Motor Skills</h4>
                    </div>
                    <div className="text-3xl text-purple-600">
                      {latestReport.typingScore}
                      <span className="text-lg text-gray-500">/100</span>
                    </div>
                    <Progress
                      value={latestReport.typingScore}
                      className="h-2"
                    />
                    <p className="text-sm text-gray-600">
                      Typing consistency, rhythm, accuracy
                    </p>
                  </div>
                </div>
              </Card>

              {/* Clinical Insights */}
              <Card className="p-6 shadow-lg">
                <h3 className="mb-4">Clinical Insights</h3>
                <div className="space-y-4">
                  {latestReport.voiceScore < 70 && (
                    <div className="flex gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-yellow-800">
                          <strong>Voice Analysis Alert:</strong> Score below
                          normal threshold. Consider evaluation for speech
                          changes or vocal tremor.
                        </p>
                      </div>
                    </div>
                  )}

                  {latestReport.faceScore < 70 && (
                    <div className="flex gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-yellow-800">
                          <strong>Facial Expression Alert:</strong> Reduced
                          facial mobility detected. May indicate masked facies
                          or expression difficulties.
                        </p>
                      </div>
                    </div>
                  )}

                  {latestReport.typingScore < 70 && (
                    <div className="flex gap-3 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-yellow-800">
                          <strong>Motor Skills Alert:</strong> Typing
                          inconsistencies detected. May suggest fine motor
                          control changes.
                        </p>
                      </div>
                    </div>
                  )}

                  {latestReport.voiceScore >= 70 &&
                    latestReport.faceScore >= 70 &&
                    latestReport.typingScore >= 70 && (
                      <div className="flex gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                        <Activity className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-green-800">
                            All metrics within acceptable range. Continue
                            regular monitoring schedule.
                          </p>
                        </div>
                      </div>
                    )}
                </div>
              </Card>
            </>
          ) : (
            <Card className="p-12 text-center">
              <Activity className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="mb-2">No Assessment Data</h3>
              <p className="text-gray-600">
                Patient has not completed any assessments yet
              </p>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          {userData.weeklyTrends.length > 0 ? (
            <>
              <Card className="p-6 shadow-lg">
                <div className="flex items-center gap-2 mb-6">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                  <h3>Performance Trends</h3>
                </div>
                <TrendChart data={userData.weeklyTrends} />
              </Card>

              <Card className="p-6 shadow-lg">
                <h3 className="mb-4">Average Scores</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="p-4 bg-teal-50 rounded-lg">
                    <p className="text-sm text-teal-700 mb-2">Voice Average</p>
                    <p className="text-3xl text-teal-600">{voiceAvg || 'N/A'}</p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-700 mb-2">Face Average</p>
                    <p className="text-3xl text-blue-600">{faceAvg || 'N/A'}</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <p className="text-sm text-purple-700 mb-2">
                      Typing Average
                    </p>
                    <p className="text-3xl text-purple-600">
                      {typingAvg || 'N/A'}
                    </p>
                  </div>
                </div>
              </Card>
            </>
          ) : (
            <Card className="p-12 text-center">
              <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="mb-2">No Trend Data</h3>
              <p className="text-gray-600">
                Insufficient data to display trends
              </p>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          {userData.reports.length > 0 ? (
            <Card className="p-6 shadow-lg">
              <h3 className="mb-4">Assessment History</h3>
              <div className="space-y-3">
                {userData.reports
                  .slice()
                  .reverse()
                  .map((report, index) => (
                    <div
                      key={report.id}
                      className="p-4 border rounded-lg hover:bg-gray-50"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="text-gray-700">
                              Assessment #{userData.reports.length - index}
                            </p>
                            <p className="text-sm text-gray-500 flex items-center gap-2">
                              <Calendar className="w-3 h-3" />
                              {new Date(report.date).toLocaleDateString(
                                'en-US',
                                {
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                }
                              )}
                            </p>
                          </div>
                        </div>
                        {getRiskBadge(report.riskLevel)}
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600 mb-1">Voice</p>
                          <p className="text-teal-600">{report.voiceScore}/100</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Face</p>
                          <p className="text-blue-600">{report.faceScore}/100</p>
                        </div>
                        <div>
                          <p className="text-gray-600 mb-1">Typing</p>
                          <p className="text-purple-600">
                            {report.typingScore}/100
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </Card>
          ) : (
            <Card className="p-12 text-center">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="mb-2">No Assessment History</h3>
              <p className="text-gray-600">
                Patient has not completed any assessments yet
              </p>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Recommendations */}
      <Card className="p-6 bg-blue-50 border-blue-200">
        <h3 className="text-blue-800 mb-4">Clinical Recommendations</h3>
        <ul className="space-y-3 text-blue-700">
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Monitor trends over multiple assessments for more accurate
              detection
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Consider follow-up neurological examination if multiple metrics
              show declining trends
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Recommend weekly or bi-weekly assessments for high-risk patients
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Use AI insights as screening tools, not definitive diagnosis
            </span>
          </li>
        </ul>
      </Card>
    </div>
  );
}
