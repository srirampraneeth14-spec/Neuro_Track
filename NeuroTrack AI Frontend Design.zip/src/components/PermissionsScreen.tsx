import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Camera, Mic, CheckCircle2, XCircle, AlertCircle } from 'lucide-react';

interface PermissionsScreenProps {
  onComplete: () => void;
}

type PermissionStatus = 'pending' | 'granted' | 'denied' | 'checking';

export function PermissionsScreen({ onComplete }: PermissionsScreenProps) {
  const [micStatus, setMicStatus] = useState<PermissionStatus>('pending');
  const [cameraStatus, setCameraStatus] = useState<PermissionStatus>('pending');
  const [hasRequested, setHasRequested] = useState(false);

  useEffect(() => {
    // Check if permissions were already granted
    checkExistingPermissions();
  }, []);

  const checkExistingPermissions = async () => {
    try {
      // Check microphone
      const micPermission = await navigator.permissions.query({
        name: 'microphone' as PermissionName,
      });
      if (micPermission.state === 'granted') {
        setMicStatus('granted');
      } else if (micPermission.state === 'denied') {
        setMicStatus('denied');
      }

      // Check camera
      const cameraPermission = await navigator.permissions.query({
        name: 'camera' as PermissionName,
      });
      if (cameraPermission.state === 'granted') {
        setCameraStatus('granted');
      } else if (cameraPermission.state === 'denied') {
        setCameraStatus('denied');
      }
    } catch (error) {
      // Permissions API not fully supported, will request directly
      console.log('Permissions API not fully supported');
    }
  };

  const requestPermissions = async () => {
    setHasRequested(true);

    // Request microphone
    setMicStatus('checking');
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
      });
      micStream.getTracks().forEach((track) => track.stop());
      setMicStatus('granted');
    } catch (error) {
      // User denied microphone access - this is expected behavior
      setMicStatus('denied');
    }

    // Request camera
    setCameraStatus('checking');
    try {
      const cameraStream = await navigator.mediaDevices.getUserMedia({
        video: true,
      });
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStatus('granted');
    } catch (error) {
      // User denied camera access - this is expected behavior
      setCameraStatus('denied');
    }
  };

  const canContinue =
    micStatus === 'granted' && cameraStatus === 'granted';
  const canSkip = hasRequested;

  const getStatusIcon = (status: PermissionStatus) => {
    switch (status) {
      case 'granted':
        return <CheckCircle2 className="w-6 h-6 text-green-600" />;
      case 'denied':
        return <XCircle className="w-6 h-6 text-red-600" />;
      case 'checking':
        return (
          <div className="w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin" />
        );
      default:
        return <AlertCircle className="w-6 h-6 text-gray-400" />;
    }
  };

  const getStatusText = (status: PermissionStatus) => {
    switch (status) {
      case 'granted':
        return 'Granted';
      case 'denied':
        return 'Denied';
      case 'checking':
        return 'Checking...';
      default:
        return 'Not requested';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full p-6 md:p-8 bg-white shadow-lg">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
            <Camera className="w-8 h-8 text-teal-600" />
          </div>
          <h2 className="mb-2">Device Permissions Required</h2>
          <p className="text-gray-600">
            NeuroDetect AI needs access to your camera and microphone to perform
            health assessments
          </p>
        </div>

        <div className="space-y-4 mb-6">
          {/* Microphone Permission */}
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center flex-shrink-0">
              <Mic className="w-6 h-6 text-teal-600" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Microphone Access</h3>
              <p className="text-sm text-gray-600">
                Required for voice pattern analysis
              </p>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(micStatus)}
              <span
                className={`text-sm ${
                  micStatus === 'granted'
                    ? 'text-green-600'
                    : micStatus === 'denied'
                    ? 'text-red-600'
                    : 'text-gray-600'
                }`}
              >
                {getStatusText(micStatus)}
              </span>
            </div>
          </div>

          {/* Camera Permission */}
          <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center flex-shrink-0">
              <Camera className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="mb-1">Camera Access</h3>
              <p className="text-sm text-gray-600">
                Required for facial expression analysis
              </p>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(cameraStatus)}
              <span
                className={`text-sm ${
                  cameraStatus === 'granted'
                    ? 'text-green-600'
                    : cameraStatus === 'denied'
                    ? 'text-red-600'
                    : 'text-gray-600'
                }`}
              >
                {getStatusText(cameraStatus)}
              </span>
            </div>
          </div>
        </div>

        {/* Denied permissions warning */}
        {(micStatus === 'denied' || cameraStatus === 'denied') && (
          <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-yellow-800 mb-2">
                  <strong>Permission Denied</strong>
                </p>
                <p className="text-sm text-yellow-700">
                  Some permissions were denied. You can still use the app, but
                  certain features will be limited. To enable all features, please
                  allow camera and microphone access in your browser settings.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Information */}
        {!hasRequested && (
          <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-blue-800 text-sm">
              <strong>Note:</strong> Your browser will ask for permission to
              access your camera and microphone. These are only used during
              assessments and are never recorded or transmitted without your
              knowledge.
            </p>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex gap-3">
          {!hasRequested ? (
            <Button
              onClick={requestPermissions}
              className="flex-1 bg-teal-600 hover:bg-teal-700"
              size="lg"
            >
              Grant Permissions
            </Button>
          ) : (
            <>
              {!canContinue && (
                <Button
                  onClick={requestPermissions}
                  variant="outline"
                  className="flex-1"
                  size="lg"
                >
                  Try Again
                </Button>
              )}
              {canSkip && (
                <Button
                  onClick={onComplete}
                  className={`flex-1 ${
                    canContinue
                      ? 'bg-teal-600 hover:bg-teal-700'
                      : 'bg-gray-600 hover:bg-gray-700'
                  }`}
                  size="lg"
                >
                  {canContinue ? 'Continue' : 'Skip for Now'}
                </Button>
              )}
            </>
          )}
        </div>

        <p className="text-xs text-gray-500 text-center mt-4">
          You can change these permissions anytime in your browser settings
        </p>
      </Card>
    </div>
  );
}
