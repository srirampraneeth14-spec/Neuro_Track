import { UserData } from '../App';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Progress } from './ui/progress';
import { DashboardCard } from './DashboardCard';
import { TrendChart } from './TrendChart';
import {
  Activity,
  Mic,
  ScanFace,
  Keyboard,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface DashboardProps {
  userData: UserData;
  onNavigate: (view: 'voice' | 'face' | 'typing' | 'reports') => void;
  onUpdateData: (data: Partial<UserData>) => void;
  calculateCombinedRisk: (
    voice: number | null,
    face: number | null,
    typing: number | null
  ) => 'low' | 'moderate' | 'high' | null;
}

export function Dashboard({
  userData,
  onNavigate,
  onUpdateData,
  calculateCombinedRisk,
}: DashboardProps) {
  const runQuickScan = async () => {
    toast.info('Starting Quick Scan...', { duration: 2000 });

    // Simulate AI analysis delay
    await new Promise((resolve) => setTimeout(resolve, 3000));

    // Generate mock scores
    const voiceScore = Math.floor(Math.random() * 30) + 70; // 70-100
    const faceScore = Math.floor(Math.random() * 30) + 70;
    const typingScore = Math.floor(Math.random() * 30) + 70;

    const combinedRisk = calculateCombinedRisk(
      voiceScore,
      faceScore,
      typingScore
    );

    // Generate mock weekly trends
    const weeklyTrends = Array.from({ length: 7 }, (_, i) => ({
      date: new Date(Date.now() - (6 - i) * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
      score: Math.floor(Math.random() * 20) + 75,
    }));

    // Add to reports
    const newReport = {
      id: Date.now().toString(),
      date: new Date().toISOString(),
      voiceScore,
      faceScore,
      typingScore,
      riskLevel: combinedRisk || 'low',
    };

    onUpdateData({
      voiceScore,
      faceScore,
      typingScore,
      combinedRisk,
      lastScanDate: new Date().toISOString(),
      weeklyTrends,
      reports: [...userData.reports, newReport],
    });

    toast.success('Quick Scan Complete!', { duration: 3000 });
  };

  const getRiskColor = (risk: 'low' | 'moderate' | 'high' | null) => {
    if (!risk) return 'bg-gray-200';
    if (risk === 'low') return 'bg-green-500';
    if (risk === 'moderate') return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getRiskTextColor = (risk: 'low' | 'moderate' | 'high' | null) => {
    if (!risk) return 'text-gray-600';
    if (risk === 'low') return 'text-green-600';
    if (risk === 'moderate') return 'text-yellow-600';
    return 'text-red-600';
  };

  const getRiskPercentage = (risk: 'low' | 'moderate' | 'high' | null) => {
    if (!risk) return 0;
    if (risk === 'low') return 85;
    if (risk === 'moderate') return 65;
    return 35;
  };

  const hasAnyData = userData.voiceScore || userData.faceScore || userData.typingScore;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-teal-500 to-blue-500 rounded-2xl p-6 md:p-8 text-white shadow-lg">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-white mb-2">Welcome to NeuroDetect AI</h2>
            <p className="opacity-90 mb-4">
              Monitor your neurological health with AI-powered analysis
            </p>
            <Button
              onClick={runQuickScan}
              size="lg"
              className="bg-white text-teal-600 hover:bg-gray-100"
            >
              <Activity className="w-5 h-5 mr-2" />
              Run Quick Scan
            </Button>
          </div>
          <div className="hidden md:block">
            <Activity className="w-20 h-20 opacity-20" />
          </div>
        </div>
      </div>

      {/* Score Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <DashboardCard
          title="Voice Analysis"
          score={userData.voiceScore}
          icon={Mic}
          color="teal"
          onClick={() => onNavigate('voice')}
        />
        <DashboardCard
          title="Face Analysis"
          score={userData.faceScore}
          icon={ScanFace}
          color="blue"
          onClick={() => onNavigate('face')}
        />
        <DashboardCard
          title="Typing Analysis"
          score={userData.typingScore}
          icon={Keyboard}
          color="purple"
          onClick={() => onNavigate('typing')}
        />
      </div>

      {/* Combined Risk Level */}
      {hasAnyData && (
        <Card className="p-6 shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            {userData.combinedRisk === 'low' ? (
              <CheckCircle2 className="w-6 h-6 text-green-600" />
            ) : (
              <AlertTriangle
                className={`w-6 h-6 ${
                  userData.combinedRisk === 'moderate'
                    ? 'text-yellow-600'
                    : 'text-red-600'
                }`}
              />
            )}
            <h3>Overall Health Score</h3>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Risk Level</span>
              <span
                className={`${getRiskTextColor(userData.combinedRisk)} capitalize`}
              >
                {userData.combinedRisk || 'No data'}
              </span>
            </div>

            <Progress
              value={getRiskPercentage(userData.combinedRisk)}
              className="h-3"
            />

            <div className="bg-gray-50 rounded-lg p-4 mt-4">
              <p className="text-gray-700">
                {userData.combinedRisk === 'low' &&
                  'Your health indicators are within normal range. Continue regular monitoring.'}
                {userData.combinedRisk === 'moderate' &&
                  'Some indicators require attention. Consider scheduling a check-up with your healthcare provider.'}
                {userData.combinedRisk === 'high' &&
                  'Multiple indicators suggest you should consult with a healthcare professional soon.'}
                {!userData.combinedRisk &&
                  'Complete assessments to view your overall health score.'}
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Weekly Trends */}
      {userData.weeklyTrends.length > 0 && (
        <Card className="p-6 shadow-lg">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="w-5 h-5 text-teal-600" />
            <h3>Weekly Health Trends</h3>
          </div>
          <TrendChart data={userData.weeklyTrends} />
        </Card>
      )}

      {/* Last Scan Info */}
      {userData.lastScanDate && (
        <Card className="p-4 bg-blue-50 border-blue-200">
          <div className="flex items-center gap-2 text-blue-800">
            <Activity className="w-5 h-5" />
            <p>
              Last scan completed on{' '}
              {new Date(userData.lastScanDate).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              })}
            </p>
          </div>
        </Card>
      )}

      {/* Get Started Guide */}
      {!hasAnyData && (
        <Card className="p-6 shadow-lg">
          <h3 className="mb-4">Get Started</h3>
          <p className="text-gray-600 mb-4">
            Complete your first assessment to start monitoring your neurological
            health:
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <Button
              variant="outline"
              onClick={() => onNavigate('voice')}
              className="justify-start h-auto py-3 border-teal-200 hover:bg-teal-50"
            >
              <Mic className="w-5 h-5 mr-2 text-teal-600" />
              <div className="text-left">
                <div className="text-teal-600">Voice Test</div>
                <div className="text-xs text-gray-500">2-3 minutes</div>
              </div>
            </Button>
            <Button
              variant="outline"
              onClick={() => onNavigate('face')}
              className="justify-start h-auto py-3 border-blue-200 hover:bg-blue-50"
            >
              <ScanFace className="w-5 h-5 mr-2 text-blue-600" />
              <div className="text-left">
                <div className="text-blue-600">Face Scan</div>
                <div className="text-xs text-gray-500">1-2 minutes</div>
              </div>
            </Button>
            <Button
              variant="outline"
              onClick={() => onNavigate('typing')}
              className="justify-start h-auto py-3 border-purple-200 hover:bg-purple-50"
            >
              <Keyboard className="w-5 h-5 mr-2 text-purple-600" />
              <div className="text-left">
                <div className="text-purple-600">Typing Test</div>
                <div className="text-xs text-gray-500">3-4 minutes</div>
              </div>
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
