import { useState } from 'react';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Card } from './ui/card';
import { Shield, Lock, Database, Activity } from 'lucide-react';

interface ConsentScreenProps {
  onConsent: () => void;
}

export function ConsentScreen({ onConsent }: ConsentScreenProps) {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full p-6 md:p-8 bg-white shadow-lg">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
            <Activity className="w-8 h-8 text-teal-600" />
          </div>
          <h1 className="text-teal-600 mb-2">NeuroDetect AI</h1>
          <p className="text-gray-600">
            Early Detection of Neurodegenerative Diseases
          </p>
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="mb-4">Privacy & Data Consent</h2>
            <p className="text-gray-600 mb-6">
              Before you begin using NeuroDetect AI, please review and accept
              our data privacy policy. Your health and privacy are our top
              priorities.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex gap-4 p-4 bg-gray-50 rounded-lg">
              <Shield className="w-6 h-6 text-teal-600 flex-shrink-0" />
              <div>
                <h3 className="mb-1">Secure Processing</h3>
                <p className="text-gray-600">
                  All voice recordings and facial scans are processed securely
                  and encrypted during transmission.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-gray-50 rounded-lg">
              <Lock className="w-6 h-6 text-teal-600 flex-shrink-0" />
              <div>
                <h3 className="mb-1">Privacy First</h3>
                <p className="text-gray-600">
                  Your data is used exclusively for health analysis and is
                  never shared with third parties without your explicit
                  consent.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-gray-50 rounded-lg">
              <Database className="w-6 h-6 text-teal-600 flex-shrink-0" />
              <div>
                <h3 className="mb-1">Data Control</h3>
                <p className="text-gray-600">
                  You have full control over your data. Delete your scans and
                  recordings anytime from Settings.
                </p>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-blue-800">
                <strong>Important:</strong> NeuroDetect AI is a screening tool
                and not a substitute for professional medical diagnosis. Always
                consult with a healthcare provider for medical advice.
              </p>
            </div>

            <div className="flex items-start gap-3 mb-6">
              <Checkbox
                id="consent"
                checked={agreed}
                onCheckedChange={(checked) => setAgreed(checked === true)}
              />
              <label htmlFor="consent" className="cursor-pointer text-gray-700">
                I have read and agree to the data privacy policy. I understand
                that my voice recordings, facial scans, and typing data will be
                analyzed for health screening purposes and stored securely.
              </label>
            </div>

            <Button
              onClick={onConsent}
              disabled={!agreed}
              className="w-full bg-teal-600 hover:bg-teal-700"
              size="lg"
            >
              Continue to NeuroDetect AI
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
