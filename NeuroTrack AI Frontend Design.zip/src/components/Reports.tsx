import { UserData } from '../App';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  FileText,
  Download,
  Share2,
  Calendar,
  TrendingUp,
  TrendingDown,
  Minus,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface ReportsProps {
  userData: UserData;
}

export function Reports({ userData }: ReportsProps) {
  const exportReport = () => {
    toast.success('Report exported successfully!', {
      description: 'Your health report has been downloaded as PDF.',
    });
  };

  const shareWithDoctor = () => {
    toast.success('Share link generated!', {
      description: 'Share this link with your healthcare provider.',
    });
  };

  const getRiskBadge = (risk: 'low' | 'moderate' | 'high') => {
    const variants = {
      low: 'bg-green-100 text-green-700 border-green-200',
      moderate: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      high: 'bg-red-100 text-red-700 border-red-200',
    };

    return (
      <Badge variant="outline" className={variants[risk]}>
        {risk.charAt(0).toUpperCase() + risk.slice(1)} Risk
      </Badge>
    );
  };

  const getTrendIcon = (current: number, previous: number | null) => {
    if (!previous) return <Minus className="w-4 h-4 text-gray-400" />;
    if (current > previous)
      return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (current < previous)
      return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  const hasData = userData.reports.length > 0;
  const latestReport = hasData ? userData.reports[userData.reports.length - 1] : null;
  const previousReport =
    userData.reports.length > 1
      ? userData.reports[userData.reports.length - 2]
      : null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="mb-2">Health Reports</h2>
          <p className="text-gray-600">
            View and export your neurological health assessments
          </p>
        </div>
        {hasData && (
          <div className="hidden md:flex gap-2">
            <Button onClick={exportReport} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
            <Button onClick={shareWithDoctor} className="bg-teal-600 hover:bg-teal-700">
              <Share2 className="w-4 h-4 mr-2" />
              Share with Doctor
            </Button>
          </div>
        )}
      </div>

      {/* Mobile Action Buttons */}
      {hasData && (
        <div className="md:hidden flex gap-2">
          <Button onClick={exportReport} variant="outline" className="flex-1">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={shareWithDoctor} className="flex-1 bg-teal-600 hover:bg-teal-700">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      )}

      {/* Latest Report Summary */}
      {latestReport && (
        <Card className="p-6 shadow-lg bg-gradient-to-br from-teal-50 to-blue-50 border-teal-200">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-teal-800 mb-1">Latest Assessment</h3>
              <p className="text-teal-600 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {new Date(latestReport.date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </p>
            </div>
            {getRiskBadge(latestReport.riskLevel)}
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-white/70 rounded-lg p-4 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <span className="text-2xl text-teal-600">
                  {latestReport.voiceScore}
                </span>
                {getTrendIcon(
                  latestReport.voiceScore,
                  previousReport?.voiceScore || null
                )}
              </div>
              <p className="text-sm text-gray-600">Voice</p>
            </div>

            <div className="bg-white/70 rounded-lg p-4 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <span className="text-2xl text-blue-600">
                  {latestReport.faceScore}
                </span>
                {getTrendIcon(
                  latestReport.faceScore,
                  previousReport?.faceScore || null
                )}
              </div>
              <p className="text-sm text-gray-600">Face</p>
            </div>

            <div className="bg-white/70 rounded-lg p-4 text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <span className="text-2xl text-purple-600">
                  {latestReport.typingScore}
                </span>
                {getTrendIcon(
                  latestReport.typingScore,
                  previousReport?.typingScore || null
                )}
              </div>
              <p className="text-sm text-gray-600">Typing</p>
            </div>
          </div>
        </Card>
      )}

      {/* Report History */}
      {hasData ? (
        <Card className="p-6 shadow-lg">
          <h3 className="mb-4">Assessment History</h3>
          <div className="space-y-3">
            {userData.reports
              .slice()
              .reverse()
              .map((report, index) => (
                <div
                  key={report.id}
                  className="p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-teal-600" />
                      </div>
                      <div>
                        <p className="text-gray-700">
                          Assessment #{userData.reports.length - index}
                        </p>
                        <p className="text-sm text-gray-500">
                          {new Date(report.date).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                    {getRiskBadge(report.riskLevel)}
                  </div>

                  <div className="grid grid-cols-3 gap-4 text-center text-sm">
                    <div>
                      <div className="text-teal-600">{report.voiceScore}</div>
                      <div className="text-gray-500">Voice</div>
                    </div>
                    <div>
                      <div className="text-blue-600">{report.faceScore}</div>
                      <div className="text-gray-500">Face</div>
                    </div>
                    <div>
                      <div className="text-purple-600">{report.typingScore}</div>
                      <div className="text-gray-500">Typing</div>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </Card>
      ) : (
        <Card className="p-12 text-center shadow-lg">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gray-100 rounded-full mb-4">
            <FileText className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="mb-2">No Reports Yet</h3>
          <p className="text-gray-600 mb-6">
            Complete your first assessment to generate a health report
          </p>
        </Card>
      )}

      {/* Report Guidelines */}
      <Card className="p-6 bg-blue-50 border-blue-200">
        <h3 className="text-blue-800 mb-3">Understanding Your Reports</h3>
        <ul className="space-y-2 text-blue-700">
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Reports track changes in voice, facial expressions, and typing
              patterns over time
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Upward trends (↑) indicate improvement, downward trends (↓) may
              require attention
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Share reports with your healthcare provider for professional
              evaluation
            </span>
          </li>
          <li className="flex items-start gap-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2" />
            <span>
              Regular assessments (weekly or monthly) provide the most valuable
              insights
            </span>
          </li>
        </ul>
      </Card>
    </div>
  );
}
