import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import {
  Settings as SettingsIcon,
  Bell,
  Shield,
  Trash2,
  LogOut,
  Database,
  Moon,
  Globe,
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from './ui/alert-dialog';
import { toast } from 'sonner@2.0.3';

interface SettingsProps {
  onClearData: () => void;
  onRevokeConsent: () => void;
  onResetPermissions?: () => void;
}

export function Settings({ onClearData, onRevokeConsent, onResetPermissions }: SettingsProps) {
  const [notifications, setNotifications] = useState(true);
  const [dataCollection, setDataCollection] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [autoBackup, setAutoBackup] = useState(false);

  const handleClearData = () => {
    onClearData();
    toast.success('All data cleared successfully');
  };

  const handleRevokeConsent = () => {
    onRevokeConsent();
    toast.info('Data consent revoked. You will be logged out.');
  };

  const handleResetPermissions = () => {
    if (onResetPermissions) {
      onResetPermissions();
      toast.info('Permissions reset. You will be asked to grant permissions again.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h2 className="mb-2">Settings</h2>
        <p className="text-gray-600">
          Manage your preferences and data privacy settings
        </p>
      </div>

      {/* Notifications */}
      <Card className="p-6 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Bell className="w-5 h-5 text-teal-600" />
          </div>
          <div className="flex-1">
            <h3 className="mb-1">Notifications</h3>
            <p className="text-gray-600 text-sm mb-4">
              Receive reminders for scheduled assessments and health insights
            </p>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="notifications" className="cursor-pointer">
                  Assessment Reminders
                </Label>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={(checked) => {
                    setNotifications(checked);
                    toast.success(
                      checked
                        ? 'Notifications enabled'
                        : 'Notifications disabled'
                    );
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Privacy & Data */}
      <Card className="p-6 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Shield className="w-5 h-5 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="mb-1">Privacy & Data</h3>
            <p className="text-gray-600 text-sm mb-4">
              Control how your data is collected and stored
            </p>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="data-collection" className="cursor-pointer">
                  Allow Data Collection
                </Label>
                <Switch
                  id="data-collection"
                  checked={dataCollection}
                  onCheckedChange={(checked) => {
                    setDataCollection(checked);
                    toast.success(
                      checked
                        ? 'Data collection enabled'
                        : 'Data collection disabled'
                    );
                  }}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="auto-backup" className="cursor-pointer">
                  Automatic Backup
                </Label>
                <Switch
                  id="auto-backup"
                  checked={autoBackup}
                  onCheckedChange={(checked) => {
                    setAutoBackup(checked);
                    toast.success(
                      checked ? 'Auto-backup enabled' : 'Auto-backup disabled'
                    );
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Appearance */}
      <Card className="p-6 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Moon className="w-5 h-5 text-purple-600" />
          </div>
          <div className="flex-1">
            <h3 className="mb-1">Appearance</h3>
            <p className="text-gray-600 text-sm mb-4">
              Customize the look and feel of the app
            </p>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="dark-mode" className="cursor-pointer">
                  Dark Mode
                </Label>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={(checked) => {
                    setDarkMode(checked);
                    toast.info(
                      checked
                        ? 'Dark mode coming soon!'
                        : 'Light mode active'
                    );
                  }}
                />
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Language */}
      <Card className="p-6 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Globe className="w-5 h-5 text-green-600" />
          </div>
          <div className="flex-1">
            <h3 className="mb-1">Language & Region</h3>
            <p className="text-gray-600 text-sm mb-4">
              Select your preferred language
            </p>
            <Button variant="outline" className="w-full md:w-auto">
              English (US)
            </Button>
          </div>
        </div>
      </Card>

      {/* Data Management */}
      <Card className="p-6 shadow-lg border-red-200">
        <div className="flex items-start gap-4">
          <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
            <Database className="w-5 h-5 text-red-600" />
          </div>
          <div className="flex-1">
            <h3 className="mb-1 text-red-600">Data Management</h3>
            <p className="text-gray-600 text-sm mb-4">
              Manage or delete your assessment data
            </p>
            <div className="space-y-3">
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="w-full border-red-200 text-red-600 hover:bg-red-50">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All Data
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Clear All Data?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently delete all your assessment data,
                      reports, and history. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleClearData}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Delete All Data
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              {onResetPermissions && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="outline" className="w-full border-yellow-200 text-yellow-600 hover:bg-yellow-50">
                      <Shield className="w-4 h-4 mr-2" />
                      Reset Camera & Mic Permissions
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Reset Permissions?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will reset your camera and microphone permissions.
                        You'll be asked to grant them again when using the app.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleResetPermissions}
                        className="bg-yellow-600 hover:bg-yellow-700"
                      >
                        Reset Permissions
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="w-full border-red-200 text-red-600 hover:bg-red-50">
                    <LogOut className="w-4 h-4 mr-2" />
                    Revoke Consent & Log Out
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Revoke Data Consent?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will revoke your data privacy consent and log you
                      out of the app. You'll need to agree to the consent terms
                      again to use NeuroDetect AI.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleRevokeConsent}
                      className="bg-red-600 hover:bg-red-700"
                    >
                      Revoke & Log Out
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </div>
      </Card>

      {/* App Info */}
      <Card className="p-6 bg-gray-50">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-br from-teal-500 to-blue-500 rounded-lg mb-2">
            <span className="text-white">ND</span>
          </div>
          <h3>NeuroDetect AI</h3>
          <p className="text-gray-600">Version 1.0.0</p>
          <p className="text-sm text-gray-500">
            © 2025 NeuroDetect AI. All rights reserved.
          </p>
        </div>
      </Card>
    </div>
  );
}
