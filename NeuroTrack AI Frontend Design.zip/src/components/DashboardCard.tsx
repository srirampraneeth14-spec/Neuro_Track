import { Card } from './ui/card';
import { Button } from './ui/button';
import { LucideIcon, ArrowRight } from 'lucide-react';
import { cn } from './ui/utils';

interface DashboardCardProps {
  title: string;
  score: number | null;
  icon: LucideIcon;
  color: 'teal' | 'blue' | 'purple';
  onClick: () => void;
}

export function DashboardCard({
  title,
  score,
  icon: Icon,
  color,
  onClick,
}: DashboardCardProps) {
  const colorClasses = {
    teal: {
      bg: 'bg-teal-50',
      text: 'text-teal-600',
      border: 'border-teal-200',
      button: 'bg-teal-600 hover:bg-teal-700',
    },
    blue: {
      bg: 'bg-blue-50',
      text: 'text-blue-600',
      border: 'border-blue-200',
      button: 'bg-blue-600 hover:bg-blue-700',
    },
    purple: {
      bg: 'bg-purple-50',
      text: 'text-purple-600',
      border: 'border-purple-200',
      button: 'bg-purple-600 hover:bg-purple-700',
    },
  };

  const colors = colorClasses[color];

  return (
    <Card className="p-6 shadow-lg hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={cn('p-3 rounded-lg', colors.bg)}>
          <Icon className={cn('w-6 h-6', colors.text)} />
        </div>
        {score !== null && (
          <div className="text-right">
            <div className={cn('text-3xl', colors.text)}>{score}</div>
            <div className="text-xs text-gray-500">/ 100</div>
          </div>
        )}
      </div>

      <h3 className="mb-2">{title}</h3>
      
      {score !== null ? (
        <div className="space-y-3">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className={cn('h-2 rounded-full transition-all', colors.button)}
              style={{ width: `${score}%` }}
            />
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={onClick}
            className={cn('w-full', colors.border, `hover:${colors.bg}`)}
          >
            View Details
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      ) : (
        <div>
          <p className="text-gray-500 text-sm mb-3">No data available</p>
          <Button
            onClick={onClick}
            size="sm"
            className={cn('w-full', colors.button)}
          >
            Start Test
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      )}
    </Card>
  );
}
