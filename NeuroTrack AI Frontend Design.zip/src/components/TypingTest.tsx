import { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Textarea } from './ui/textarea';
import {
  Keyboard,
  Play,
  CheckCircle2,
  RotateCcw,
  Timer,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface TypingTestProps {
  onComplete: (score: number) => void;
}

const testPhrases = [
  'The quick brown fox jumps over the lazy dog near the riverbank.',
  'Scientific research suggests that early detection can significantly improve treatment outcomes.',
  'Regular monitoring and preventive care are essential components of modern healthcare.',
  'Technology continues to revolutionize how we approach medical diagnosis and treatment.',
  'A healthy lifestyle includes proper nutrition, regular exercise, and adequate rest.',
];

interface TypingMetrics {
  wpm: number;
  accuracy: number;
  consistency: number;
  rhythm: number;
  keyPressIntervals: number[];
  errors: number;
}

export function TypingTest({ onComplete }: TypingTestProps) {
  const [isActive, setIsActive] = useState(false);
  const [currentPhrase, setCurrentPhrase] = useState('');
  const [userInput, setUserInput] = useState('');
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [keyPressTimes, setKeyPressTimes] = useState<number[]>([]);
  const [result, setResult] = useState<{
    score: number;
    metrics: TypingMetrics;
  } | null>(null);

  const timerRef = useRef<number | null>(null);
  const lastKeyPressRef = useRef<number>(0);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  const startTest = () => {
    const phrase = testPhrases[Math.floor(Math.random() * testPhrases.length)];
    setCurrentPhrase(phrase);
    setUserInput('');
    setIsActive(true);
    setStartTime(Date.now());
    setElapsedTime(0);
    setKeyPressTimes([]);
    lastKeyPressRef.current = Date.now();

    timerRef.current = window.setInterval(() => {
      setElapsedTime((prev) => prev + 0.1);
    }, 100);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (!isActive) return;

    const newValue = e.target.value;
    const now = Date.now();
    const interval = now - lastKeyPressRef.current;

    if (newValue.length > userInput.length) {
      setKeyPressTimes((prev) => [...prev, interval]);
    }

    lastKeyPressRef.current = now;
    setUserInput(newValue);

    // Auto-complete when user finishes typing
    if (newValue.length >= currentPhrase.length) {
      completeTest();
    }
  };

  const completeTest = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setIsActive(false);
    analyzeTyping();
  };

  const analyzeTyping = () => {
    const timeInMinutes = elapsedTime / 60;
    const wordsTyped = userInput.trim().split(/\s+/).length;
    const wpm = Math.round(wordsTyped / timeInMinutes);

    // Calculate accuracy
    let correctChars = 0;
    for (let i = 0; i < Math.min(userInput.length, currentPhrase.length); i++) {
      if (userInput[i] === currentPhrase[i]) {
        correctChars++;
      }
    }
    const accuracy = Math.round(
      (correctChars / currentPhrase.length) * 100
    );

    // Calculate consistency (lower variance in key press intervals = higher consistency)
    const avgInterval =
      keyPressTimes.reduce((a, b) => a + b, 0) / keyPressTimes.length;
    const variance =
      keyPressTimes.reduce((sum, interval) => {
        return sum + Math.pow(interval - avgInterval, 2);
      }, 0) / keyPressTimes.length;
    const stdDev = Math.sqrt(variance);
    const consistency = Math.max(
      0,
      Math.min(100, Math.round(100 - stdDev / 10))
    );

    // Calculate rhythm (regularity of typing)
    const rhythm = Math.round((consistency + accuracy) / 2);

    // Calculate overall score
    const wpmScore = Math.min(100, (wpm / 60) * 100); // Normalize to 100
    const score = Math.round(
      (wpmScore * 0.3 + accuracy * 0.4 + consistency * 0.2 + rhythm * 0.1)
    );

    const errors = currentPhrase.length - correctChars;

    setResult({
      score,
      metrics: {
        wpm,
        accuracy,
        consistency,
        rhythm,
        keyPressIntervals: keyPressTimes,
        errors,
      },
    });

    toast.success('Typing analysis complete!');
  };

  const reset = () => {
    setIsActive(false);
    setCurrentPhrase('');
    setUserInput('');
    setStartTime(null);
    setElapsedTime(0);
    setKeyPressTimes([]);
    setResult(null);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  const saveResults = () => {
    if (result) {
      onComplete(result.score);
      toast.success('Typing analysis saved!');
    }
  };

  const getCharClassName = (index: number) => {
    if (index >= userInput.length) return 'text-gray-400';
    if (userInput[index] === currentPhrase[index]) return 'text-green-600';
    return 'text-red-600';
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h2 className="text-purple-600 mb-2">Typing Speed & Pattern Analysis</h2>
        <p className="text-gray-600">
          Analyze typing patterns, speed, and consistency to detect fine motor
          skill changes
        </p>
      </div>

      {/* Test Card */}
      <Card className="p-6 shadow-lg">
        <div className="space-y-6">
          {!currentPhrase && !result && (
            <div className="text-center py-12">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-purple-100 rounded-full mb-4">
                <Keyboard className="w-10 h-10 text-purple-600" />
              </div>
              <h3 className="mb-2">Ready to Start</h3>
              <p className="text-gray-600 mb-6">
                Click the button below to begin the typing test
              </p>
              <Button
                onClick={startTest}
                size="lg"
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Play className="w-5 h-5 mr-2" />
                Start Typing Test
              </Button>
            </div>
          )}

          {currentPhrase && !result && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Timer className="w-5 h-5 text-purple-600" />
                  <span className="text-purple-600">
                    Time: {elapsedTime.toFixed(1)}s
                  </span>
                </div>
                <div className="text-purple-600">
                  Progress: {Math.round((userInput.length / currentPhrase.length) * 100)}%
                </div>
              </div>

              <div className="p-6 bg-gray-50 rounded-lg border-2 border-gray-200">
                <p className="text-lg leading-relaxed mb-4 font-mono">
                  {currentPhrase.split('').map((char, index) => (
                    <span key={index} className={getCharClassName(index)}>
                      {char}
                    </span>
                  ))}
                </p>

                <Textarea
                  value={userInput}
                  onChange={handleInputChange}
                  placeholder="Start typing here..."
                  className="min-h-32 resize-none text-lg font-mono"
                  autoFocus
                  disabled={!isActive}
                />
              </div>

              <div className="flex gap-3">
                <Button onClick={completeTest} variant="outline" className="flex-1">
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Complete Test
                </Button>
                <Button onClick={reset} variant="outline" className="flex-1">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Restart
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Instructions */}
      {!currentPhrase && !result && (
        <Card className="p-6 bg-purple-50 border-purple-200">
          <h3 className="text-purple-800 mb-3">Test Instructions</h3>
          <ul className="space-y-2 text-purple-700">
            <li className="flex items-start gap-2">
              <Keyboard className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>Type the displayed phrase as accurately as possible</span>
            </li>
            <li className="flex items-start gap-2">
              <Keyboard className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Focus on maintaining your natural typing rhythm and speed
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Keyboard className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                The test will analyze your typing consistency and pattern
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Keyboard className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Don't rush - accuracy is more important than speed
              </span>
            </li>
          </ul>
        </Card>
      )}

      {/* Results */}
      {result && (
        <Card className="p-6 shadow-lg space-y-6">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-purple-100 rounded-full mb-4">
              <span className="text-3xl text-purple-600">{result.score}</span>
            </div>
            <h3 className="mb-2">Typing Analysis Score</h3>
            <p className="text-gray-600">
              Your typing patterns are{' '}
              {result.score >= 80
                ? 'excellent and consistent'
                : result.score >= 60
                ? 'good with minor variations'
                : 'showing some inconsistencies'}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl text-purple-600 mb-1">
                {result.metrics.wpm}
              </div>
              <div className="text-sm text-gray-600">Words per Minute</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-purple-600 mb-1">
                {result.metrics.errors}
              </div>
              <div className="text-sm text-gray-600">Errors</div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Typing Accuracy</span>
                <span className="text-purple-600">
                  {result.metrics.accuracy}%
                </span>
              </div>
              <Progress value={result.metrics.accuracy} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Consistency</span>
                <span className="text-purple-600">
                  {result.metrics.consistency}%
                </span>
              </div>
              <Progress value={result.metrics.consistency} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Typing Rhythm</span>
                <span className="text-purple-600">
                  {result.metrics.rhythm}%
                </span>
              </div>
              <Progress value={result.metrics.rhythm} className="h-2" />
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-blue-800">
              <strong>Insight:</strong>{' '}
              {result.metrics.consistency >= 80
                ? 'Your typing shows excellent motor control consistency.'
                : result.metrics.consistency >= 60
                ? 'Your typing shows good consistency with minor variations.'
                : 'Variations in typing rhythm detected. Consider regular monitoring.'}
            </p>
          </div>

          <div className="flex gap-3">
            <Button onClick={reset} variant="outline" className="flex-1">
              <RotateCcw className="w-4 h-4 mr-2" />
              Test Again
            </Button>
            <Button
              onClick={saveResults}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Save Results
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
