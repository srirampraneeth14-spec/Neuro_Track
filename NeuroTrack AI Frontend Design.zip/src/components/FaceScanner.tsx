import { useState, useRef, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import {
  Camera,
  CameraOff,
  Scan,
  CheckCircle2,
  RotateCcw,
  Eye,
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { motion } from 'motion/react';
import { PermissionCheck } from './PermissionCheck';

interface FaceScannerProps {
  onComplete: (score: number) => void;
}

export function FaceScanner({ onComplete }: FaceScannerProps) {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [result, setResult] = useState<{
    score: number;
    metrics: {
      symmetry: number;
      expressions: number;
      eyeMovement: number;
      microExpressions: number;
    };
  } | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 640, height: 480 },
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsCameraActive(true);
        toast.success('Camera activated');
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === 'NotAllowedError') {
        toast.error('Camera access denied. Please enable it in your browser settings.');
      } else {
        toast.error('Could not access camera. Please check your device settings.');
      }
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const captureFrame = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/png');
        setCapturedImage(imageData);
        stopCamera();
        toast.info('Image captured');
      }
    }
  };

  const analyzeFace = async () => {
    setIsScanning(true);
    setScanProgress(0);

    // Simulate AI analysis with progress
    for (let i = 0; i <= 100; i += 5) {
      await new Promise((resolve) => setTimeout(resolve, 100));
      setScanProgress(i);
    }

    // Generate mock analysis results
    const symmetry = Math.floor(Math.random() * 20) + 80;
    const expressions = Math.floor(Math.random() * 20) + 75;
    const eyeMovement = Math.floor(Math.random() * 25) + 70;
    const microExpressions = Math.floor(Math.random() * 20) + 75;
    const averageScore = Math.floor(
      (symmetry + expressions + eyeMovement + microExpressions) / 4
    );

    setResult({
      score: averageScore,
      metrics: { symmetry, expressions, eyeMovement, microExpressions },
    });

    setIsScanning(false);
    toast.success('Facial analysis complete!');
  };

  const reset = () => {
    setCapturedImage(null);
    setResult(null);
    setScanProgress(0);
  };

  const saveResults = () => {
    if (result) {
      onComplete(result.score);
      toast.success('Facial analysis saved!');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
      <div>
        <h2 className="text-blue-600 mb-2">Facial Expression Analysis</h2>
        <p className="text-gray-600">
          Analyze facial expressions and micro-movements for early detection of
          neurological changes
        </p>
      </div>

      {/* Permission Check */}
      <PermissionCheck type="camera" />

      {/* Camera/Preview Card */}
      <Card className="p-6 shadow-lg">
        <div className="space-y-6">
          {/* Camera Feed or Captured Image */}
          <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video">
            {isCameraActive && !capturedImage && (
              <>
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
                <motion.div
                  className="absolute inset-0 border-4 border-blue-500 rounded-lg pointer-events-none"
                  animate={{
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                />
                <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full flex items-center gap-2">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                  <span className="text-sm">Live</span>
                </div>
              </>
            )}

            {capturedImage && (
              <img
                src={capturedImage}
                alt="Captured face"
                className="w-full h-full object-cover"
              />
            )}

            {!isCameraActive && !capturedImage && (
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-center text-gray-400">
                  <Camera className="w-16 h-16 mx-auto mb-4" />
                  <p>Camera not active</p>
                </div>
              </div>
            )}

            <canvas ref={canvasRef} className="hidden" />
          </div>

          {/* Controls */}
          <div className="flex justify-center gap-3 flex-wrap">
            {!isCameraActive && !capturedImage && (
              <Button
                onClick={startCamera}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Camera className="w-5 h-5 mr-2" />
                Activate Camera
              </Button>
            )}

            {isCameraActive && !capturedImage && (
              <>
                <Button onClick={captureFrame} size="lg" className="bg-blue-600 hover:bg-blue-700">
                  <Scan className="w-5 h-5 mr-2" />
                  Capture Frame
                </Button>
                <Button onClick={stopCamera} variant="outline" size="lg">
                  <CameraOff className="w-5 h-5 mr-2" />
                  Stop Camera
                </Button>
              </>
            )}

            {capturedImage && !result && (
              <>
                <Button onClick={reset} variant="outline" size="lg">
                  <RotateCcw className="w-5 h-5 mr-2" />
                  Retake
                </Button>
                <Button
                  onClick={analyzeFace}
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Scan className="w-5 h-5 mr-2" />
                  Analyze Face
                </Button>
              </>
            )}
          </div>

          {isScanning && (
            <div className="space-y-3">
              <p className="text-center text-gray-600">
                Analyzing facial expressions...
              </p>
              <Progress value={scanProgress} className="h-2" />
              <p className="text-center text-sm text-gray-500">{scanProgress}%</p>
            </div>
          )}
        </div>
      </Card>

      {/* Instructions */}
      {!capturedImage && !result && (
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="text-blue-800 mb-3">Scanning Instructions</h3>
          <ul className="space-y-2 text-blue-700">
            <li className="flex items-start gap-2">
              <Eye className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Position your face in the center of the frame in good lighting
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Eye className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Look directly at the camera with a neutral expression
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Eye className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Ensure your entire face is visible without obstructions
              </span>
            </li>
            <li className="flex items-start gap-2">
              <Eye className="w-5 h-5 flex-shrink-0 mt-0.5" />
              <span>
                Remove glasses or accessories that might interfere with the scan
              </span>
            </li>
          </ul>
        </Card>
      )}

      {/* Results */}
      {result && (
        <Card className="p-6 shadow-lg space-y-6">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 rounded-full mb-4">
              <span className="text-3xl text-blue-600">{result.score}</span>
            </div>
            <h3 className="mb-2">Facial Expression Score</h3>
            <p className="text-gray-600">
              Your facial patterns are{' '}
              {result.score >= 80
                ? 'within normal range'
                : result.score >= 60
                ? 'showing minor variations'
                : 'showing notable variations'}
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Facial Symmetry</span>
                <span className="text-blue-600">{result.metrics.symmetry}%</span>
              </div>
              <Progress value={result.metrics.symmetry} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Expression Range</span>
                <span className="text-blue-600">
                  {result.metrics.expressions}%
                </span>
              </div>
              <Progress value={result.metrics.expressions} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Eye Movement</span>
                <span className="text-blue-600">
                  {result.metrics.eyeMovement}%
                </span>
              </div>
              <Progress value={result.metrics.eyeMovement} className="h-2" />
            </div>

            <div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-700">Micro-expressions</span>
                <span className="text-blue-600">
                  {result.metrics.microExpressions}%
                </span>
              </div>
              <Progress value={result.metrics.microExpressions} className="h-2" />
            </div>
          </div>

          <div className="flex gap-3">
            <Button onClick={reset} variant="outline" className="flex-1">
              <RotateCcw className="w-4 h-4 mr-2" />
              Scan Again
            </Button>
            <Button
              onClick={saveResults}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Save Results
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
