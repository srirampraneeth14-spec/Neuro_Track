import {
  LayoutDashboard,
  Mic,
  ScanFace,
  Keyboard,
  FileText,
  Settings,
  Stethoscope,
} from 'lucide-react';
import { Button } from './ui/button';
import { cn } from './ui/utils';

interface NavigationProps {
  currentView:
    | 'dashboard'
    | 'voice'
    | 'face'
    | 'typing'
    | 'reports'
    | 'settings'
    | 'doctor';
  onViewChange: (
    view:
      | 'dashboard'
      | 'voice'
      | 'face'
      | 'typing'
      | 'reports'
      | 'settings'
      | 'doctor'
  ) => void;
  isDoctorMode: boolean;
  onToggleDoctorMode: () => void;
}

export function Navigation({
  currentView,
  onViewChange,
  isDoctorMode,
  onToggleDoctorMode,
}: NavigationProps) {
  const navItems = [
    { id: 'dashboard' as const, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'voice' as const, label: 'Voice', icon: Mic },
    { id: 'face' as const, label: 'Face', icon: ScanFace },
    { id: 'typing' as const, label: 'Typing', icon: Keyboard },
    { id: 'reports' as const, label: 'Reports', icon: FileText },
    { id: 'settings' as const, label: 'Settings', icon: Settings },
  ];

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:block bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-500 rounded-lg flex items-center justify-center">
                <span className="text-white">ND</span>
              </div>
              <div>
                <h1 className="text-teal-600">NeuroDetect AI</h1>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Button
                    key={item.id}
                    variant={currentView === item.id && !isDoctorMode ? 'default' : 'ghost'}
                    onClick={() => {
                      onViewChange(item.id);
                      if (isDoctorMode) onToggleDoctorMode();
                    }}
                    className={cn(
                      currentView === item.id && !isDoctorMode
                        ? 'bg-teal-600 hover:bg-teal-700 text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    )}
                  >
                    <Icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                );
              })}

              <div className="ml-4 pl-4 border-l border-gray-200">
                <Button
                  variant={isDoctorMode ? 'default' : 'outline'}
                  onClick={onToggleDoctorMode}
                  className={cn(
                    isDoctorMode
                      ? 'bg-blue-600 hover:bg-blue-700 text-white'
                      : 'text-blue-600 border-blue-200 hover:bg-blue-50'
                  )}
                >
                  <Stethoscope className="w-4 h-4 mr-2" />
                  Doctor View
                </Button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation */}
      <div className="md:hidden">
        {/* Mobile Header */}
        <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
          <div className="flex items-center justify-between px-4 h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-blue-500 rounded-lg flex items-center justify-center">
                <span className="text-white">ND</span>
              </div>
              <div>
                <h1 className="text-teal-600">NeuroDetect AI</h1>
              </div>
            </div>

            <Button
              variant={isDoctorMode ? 'default' : 'outline'}
              size="sm"
              onClick={onToggleDoctorMode}
              className={cn(
                isDoctorMode
                  ? 'bg-blue-600 hover:bg-blue-700 text-white'
                  : 'text-blue-600 border-blue-200'
              )}
            >
              <Stethoscope className="w-4 h-4 mr-1" />
              Doctor
            </Button>
          </div>
        </div>

        {/* Mobile Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
          <div className="grid grid-cols-6 gap-1 px-2 py-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id && !isDoctorMode;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onViewChange(item.id);
                    if (isDoctorMode) onToggleDoctorMode();
                  }}
                  className={cn(
                    'flex flex-col items-center justify-center py-2 px-1 rounded-lg transition-colors',
                    isActive
                      ? 'bg-teal-50 text-teal-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  )}
                >
                  <Icon className="w-5 h-5 mb-1" />
                  <span className="text-xs">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
