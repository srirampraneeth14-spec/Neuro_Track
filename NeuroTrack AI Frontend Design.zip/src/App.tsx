import { useState, useEffect } from 'react';
import { ConsentScreen } from './components/ConsentScreen';
import { PermissionsScreen } from './components/PermissionsScreen';
import { Dashboard } from './components/Dashboard';
import { VoiceTest } from './components/VoiceTest';
import { FaceScanner } from './components/FaceScanner';
import { TypingTest } from './components/TypingTest';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';
import { DoctorView } from './components/DoctorView';
import { Navigation } from './components/Navigation';
import { Toaster } from './components/ui/sonner';

export type UserData = {
  voiceScore: number | null;
  faceScore: number | null;
  typingScore: number | null;
  combinedRisk: 'low' | 'moderate' | 'high' | null;
  lastScanDate: string | null;
  weeklyTrends: Array<{ date: string; score: number }>;
  reports: Array<{
    id: string;
    date: string;
    voiceScore: number;
    faceScore: number;
    typingScore: number;
    riskLevel: 'low' | 'moderate' | 'high';
  }>;
};

export default function App() {
  const [hasConsented, setHasConsented] = useState(false);
  const [hasPermissions, setHasPermissions] = useState(false);
  const [currentView, setCurrentView] = useState<
    'dashboard' | 'voice' | 'face' | 'typing' | 'reports' | 'settings' | 'doctor'
  >('dashboard');
  const [isDoctorMode, setIsDoctorMode] = useState(false);

  const [userData, setUserData] = useState<UserData>({
    voiceScore: null,
    faceScore: null,
    typingScore: null,
    combinedRisk: null,
    lastScanDate: null,
    weeklyTrends: [],
    reports: [],
  });

  useEffect(() => {
    // Load consent status from localStorage
    const consent = localStorage.getItem('neurodetect_consent');
    if (consent === 'true') {
      setHasConsented(true);
    }

    // Load permissions status from localStorage
    const permissions = localStorage.getItem('neurodetect_permissions');
    if (permissions === 'true') {
      setHasPermissions(true);
    }

    // Load user data from localStorage
    const savedData = localStorage.getItem('neurodetect_data');
    if (savedData) {
      setUserData(JSON.parse(savedData));
    }
  }, []);

  const handleConsent = () => {
    setHasConsented(true);
    localStorage.setItem('neurodetect_consent', 'true');
  };

  const handlePermissionsComplete = () => {
    setHasPermissions(true);
    localStorage.setItem('neurodetect_permissions', 'true');
  };

  const updateUserData = (newData: Partial<UserData>) => {
    const updated = { ...userData, ...newData };
    setUserData(updated);
    localStorage.setItem('neurodetect_data', JSON.stringify(updated));
  };

  const calculateCombinedRisk = (
    voice: number | null,
    face: number | null,
    typing: number | null
  ): 'low' | 'moderate' | 'high' | null => {
    const scores = [voice, face, typing].filter((s) => s !== null) as number[];
    if (scores.length === 0) return null;

    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;

    if (avg >= 80) return 'low';
    if (avg >= 60) return 'moderate';
    return 'high';
  };

  if (!hasConsented) {
    return <ConsentScreen onConsent={handleConsent} />;
  }

  if (!hasPermissions) {
    return <PermissionsScreen onComplete={handlePermissionsComplete} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation
        currentView={currentView}
        onViewChange={setCurrentView}
        isDoctorMode={isDoctorMode}
        onToggleDoctorMode={() => setIsDoctorMode(!isDoctorMode)}
      />

      <main className="pb-20 md:pb-6">
        {currentView === 'dashboard' && !isDoctorMode && (
          <Dashboard
            userData={userData}
            onNavigate={setCurrentView}
            onUpdateData={updateUserData}
            calculateCombinedRisk={calculateCombinedRisk}
          />
        )}

        {currentView === 'voice' && !isDoctorMode && (
          <VoiceTest
            onComplete={(score) => {
              const combinedRisk = calculateCombinedRisk(
                score,
                userData.faceScore,
                userData.typingScore
              );
              updateUserData({
                voiceScore: score,
                combinedRisk,
                lastScanDate: new Date().toISOString(),
              });
            }}
          />
        )}

        {currentView === 'face' && !isDoctorMode && (
          <FaceScanner
            onComplete={(score) => {
              const combinedRisk = calculateCombinedRisk(
                userData.voiceScore,
                score,
                userData.typingScore
              );
              updateUserData({
                faceScore: score,
                combinedRisk,
                lastScanDate: new Date().toISOString(),
              });
            }}
          />
        )}

        {currentView === 'typing' && !isDoctorMode && (
          <TypingTest
            onComplete={(score) => {
              const combinedRisk = calculateCombinedRisk(
                userData.voiceScore,
                userData.faceScore,
                score
              );
              updateUserData({
                typingScore: score,
                combinedRisk,
                lastScanDate: new Date().toISOString(),
              });
            }}
          />
        )}

        {currentView === 'reports' && !isDoctorMode && (
          <Reports userData={userData} />
        )}

        {currentView === 'settings' && !isDoctorMode && (
          <Settings
            onClearData={() => {
              setUserData({
                voiceScore: null,
                faceScore: null,
                typingScore: null,
                combinedRisk: null,
                lastScanDate: null,
                weeklyTrends: [],
                reports: [],
              });
              localStorage.removeItem('neurodetect_data');
            }}
            onRevokeConsent={() => {
              setHasConsented(false);
              localStorage.removeItem('neurodetect_consent');
            }}
            onResetPermissions={() => {
              setHasPermissions(false);
              localStorage.removeItem('neurodetect_permissions');
            }}
          />
        )}

        {isDoctorMode && <DoctorView userData={userData} />}
      </main>

      <Toaster />
    </div>
  );
}
