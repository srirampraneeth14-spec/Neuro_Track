import { LucideIcon } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  score: number | null;
  icon: LucideIcon;
  color: string;
  subtitle?: string;
}

export default function DashboardCard({ title, score, icon: Icon, color, subtitle }: DashboardCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 85) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-12 h-12 ${color} bg-opacity-10 rounded-lg flex items-center justify-center`}>
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
        {score !== null && (
          <div className={`text-3xl font-bold ${getScoreColor(score)}`}>
            {score}
          </div>
        )}
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-1">{title}</h3>
      {subtitle && <p className="text-sm text-gray-500">{subtitle}</p>}
      {score === null && (
        <p className="text-sm text-gray-400 mt-2">No data yet</p>
      )}
    </div>
  );
}
