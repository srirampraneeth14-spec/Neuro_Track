import { useState } from 'react';
import { Shield, Lock, Eye, CheckCircle2 } from 'lucide-react';

interface ConsentScreenProps {
  onConsent: () => void;
}

export default function ConsentScreen({ onConsent }: ConsentScreenProps) {
  const [agreed, setAgreed] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-8 md:p-12">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-teal-100 rounded-full mb-4">
            <Shield className="w-10 h-10 text-teal-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to NeuroDetect AI</h1>
          <p className="text-gray-600">Early detection for better health outcomes</p>
        </div>

        <div className="space-y-6 mb-8">
          <div className="border-l-4 border-teal-500 pl-4">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Privacy & Data Usage</h2>
            <p className="text-gray-700 mb-4">
              NeuroDetect AI uses advanced algorithms to analyze voice patterns, facial expressions, and typing behavior
              to help detect early signs of neurodegenerative diseases like Parkinson's and Alzheimer's.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-teal-50 rounded-lg p-4">
              <Lock className="w-6 h-6 text-teal-600 mb-2" />
              <h3 className="font-semibold text-gray-900 mb-1">Secure Processing</h3>
              <p className="text-sm text-gray-600">Your data is encrypted and processed securely</p>
            </div>
            <div className="bg-blue-50 rounded-lg p-4">
              <Eye className="w-6 h-6 text-blue-600 mb-2" />
              <h3 className="font-semibold text-gray-900 mb-1">Health Only</h3>
              <p className="text-sm text-gray-600">Data used exclusively for health analysis</p>
            </div>
            <div className="bg-green-50 rounded-lg p-4">
              <CheckCircle2 className="w-6 h-6 text-green-600 mb-2" />
              <h3 className="font-semibold text-gray-900 mb-1">Your Control</h3>
              <p className="text-sm text-gray-600">Delete your data anytime from settings</p>
            </div>
          </div>

          <div className="bg-gray-50 rounded-lg p-6">
            <h3 className="font-semibold text-gray-900 mb-3">We collect:</h3>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start">
                <span className="text-teal-600 mr-2">•</span>
                <span>Voice recordings for acoustic analysis</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-600 mr-2">•</span>
                <span>Facial expression data from camera snapshots</span>
              </li>
              <li className="flex items-start">
                <span className="text-teal-600 mr-2">•</span>
                <span>Typing patterns and speed metrics</span>
              </li>
            </ul>
            <p className="text-sm text-gray-600 mt-4">
              This information is used solely to provide you with health insights and is never shared with third parties
              without your explicit consent.
            </p>
          </div>
        </div>

        <div className="border-t pt-6">
          <label className="flex items-start cursor-pointer mb-6">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
              className="mt-1 w-5 h-5 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
            />
            <span className="ml-3 text-gray-700">
              I agree to the collection and processing of my data for health analysis purposes.
              I understand that I can withdraw consent and delete my data at any time from the settings.
            </span>
          </label>

          <button
            onClick={onConsent}
            disabled={!agreed}
            className={`w-full py-4 rounded-xl font-semibold text-lg transition-all ${
              agreed
                ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            Continue to App
          </button>
        </div>
      </div>
    </div>
  );
}
