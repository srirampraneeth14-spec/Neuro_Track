import { FileText, Download, Share2, Calendar, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { VoiceAnalysis, FaceAnalysis, TypingAnalysis, RiskLevel } from '../types';
import { calculateRiskLevel } from '../utils/mockAnalysis';

interface ReportsProps {
  voiceData: VoiceAnalysis | null;
  faceData: FaceAnalysis | null;
  typingData: TypingAnalysis | null;
}

export default function Reports({ voiceData, faceData, typingData }: ReportsProps) {
  const hasData = voiceData || faceData || typingData;

  const riskLevel: RiskLevel = voiceData && faceData && typingData
    ? calculateRiskLevel(voiceData.score, faceData.score, typingData.score)
    : 'Low';

  const avgScore = voiceData && faceData && typingData
    ? Math.round((voiceData.score + faceData.score + typingData.score) / 3)
    : null;

  const getRecommendations = (risk: RiskLevel): string[] => {
    switch (risk) {
      case 'High':
        return [
          'Schedule an appointment with a neurologist for comprehensive evaluation',
          'Continue regular monitoring with weekly assessments',
          'Keep a detailed log of any symptoms or changes you notice',
          'Consider getting a family member involved in monitoring',
        ];
      case 'Moderate':
        return [
          'Continue monitoring with bi-weekly assessments',
          'Consult your healthcare provider about these results',
          'Maintain a healthy lifestyle with regular exercise',
          'Track any changes in symptoms or patterns',
        ];
      case 'Low':
        return [
          'Continue monthly monitoring for baseline tracking',
          'Maintain healthy lifestyle habits',
          'No immediate medical consultation required',
          'Keep using the app for early detection benefits',
        ];
    }
  };

  const handleExport = () => {
    alert('Export functionality would generate a PDF report in a production environment.');
  };

  const handleShare = () => {
    alert('Share functionality would allow secure sharing with healthcare providers.');
  };

  const formatDate = (date: Date | undefined) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getTrendIcon = (score: number) => {
    if (score >= 85) return <TrendingUp className="w-5 h-5 text-green-600" />;
    if (score >= 70) return <Minus className="w-5 h-5 text-yellow-600" />;
    return <TrendingDown className="w-5 h-5 text-red-600" />;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Health Reports</h1>
        <p className="text-gray-600">View and export your neurological health assessments</p>
      </div>

      {!hasData ? (
        <div className="bg-white rounded-xl shadow-md p-12 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gray-100 rounded-full mb-4">
            <FileText className="w-10 h-10 text-gray-400" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">No Reports Available</h2>
          <p className="text-gray-600 mb-6">
            Complete some assessments to generate your first health report
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-md p-8">
            <div className="flex items-center justify-between mb-6 pb-6 border-b">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">Health Assessment Report</h2>
                <div className="flex items-center text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span className="text-sm">
                    Generated on {formatDate(voiceData?.timestamp || faceData?.timestamp || typingData?.timestamp)}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold mb-2 ${
                  riskLevel === 'Low' ? 'bg-green-100 text-green-800' :
                  riskLevel === 'Moderate' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {riskLevel} Risk Level
                </div>
                {avgScore !== null && (
                  <div className="text-3xl font-bold text-gray-900">{avgScore}/100</div>
                )}
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {voiceData && (
                <div className="bg-teal-50 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">Voice Analysis</h3>
                    {getTrendIcon(voiceData.score)}
                  </div>
                  <div className="text-3xl font-bold text-teal-600 mb-1">{voiceData.score}</div>
                  <div className="text-sm text-gray-600">
                    Duration: {voiceData.duration}s
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    {formatDate(voiceData.timestamp)}
                  </div>
                </div>
              )}

              {faceData && (
                <div className="bg-blue-50 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">Face Scan</h3>
                    {getTrendIcon(faceData.score)}
                  </div>
                  <div className="text-3xl font-bold text-blue-600 mb-1">{faceData.score}</div>
                  <div className="text-sm text-gray-600">
                    Expression: {faceData.expression}
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    {formatDate(faceData.timestamp)}
                  </div>
                </div>
              )}

              {typingData && (
                <div className="bg-purple-50 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">Typing Test</h3>
                    {getTrendIcon(typingData.score)}
                  </div>
                  <div className="text-3xl font-bold text-purple-600 mb-1">{typingData.score}</div>
                  <div className="text-sm text-gray-600">
                    {typingData.wpm} WPM, {typingData.accuracy}% accuracy
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    {formatDate(typingData.timestamp)}
                  </div>
                </div>
              )}
            </div>

            <div className="bg-gray-50 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">Clinical Recommendations</h3>
              <ul className="space-y-3">
                {getRecommendations(riskLevel).map((rec, index) => (
                  <li key={index} className="flex items-start text-gray-700">
                    <span className="text-teal-600 font-bold mr-3 mt-0.5">{index + 1}.</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-blue-50 rounded-lg p-6">
              <h4 className="font-semibold text-gray-900 mb-2">Important Notice</h4>
              <p className="text-sm text-gray-700">
                This report is generated by AI analysis and should not be used as a substitute for professional
                medical advice, diagnosis, or treatment. Always consult with a qualified healthcare provider regarding
                any health concerns or before making any decisions related to your health or treatment.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <button
              onClick={handleExport}
              className="py-4 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-xl font-semibold hover:from-teal-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              <span className="flex items-center justify-center">
                <Download className="w-5 h-5 mr-2" />
                Export as PDF
              </span>
            </button>

            <button
              onClick={handleShare}
              className="py-4 bg-white border-2 border-teal-600 text-teal-600 rounded-xl font-semibold hover:bg-teal-50 transition-all"
            >
              <span className="flex items-center justify-center">
                <Share2 className="w-5 h-5 mr-2" />
                Share with Doctor
              </span>
            </button>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Assessment History</h3>
            <div className="space-y-3">
              {voiceData && (
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Voice Analysis</div>
                    <div className="text-sm text-gray-600">{formatDate(voiceData.timestamp)}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-teal-600">{voiceData.score}</div>
                    <div className="text-xs text-gray-500">Score</div>
                  </div>
                </div>
              )}
              {faceData && (
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Face Scan</div>
                    <div className="text-sm text-gray-600">{formatDate(faceData.timestamp)}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-blue-600">{faceData.score}</div>
                    <div className="text-xs text-gray-500">Score</div>
                  </div>
                </div>
              )}
              {typingData && (
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium text-gray-900">Typing Test</div>
                    <div className="text-sm text-gray-600">{formatDate(typingData.timestamp)}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-purple-600">{typingData.score}</div>
                    <div className="text-xs text-gray-500">Score</div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
