import { useState } from 'react';
import { Settings as SettingsIcon, Shield, Trash2, Bell, Database, User, Info } from 'lucide-react';

export default function Settings() {
  const [dataCollection, setDataCollection] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [autoBackup, setAutoBackup] = useState(false);

  const handleDeleteData = () => {
    if (window.confirm('Are you sure you want to delete all your health data? This action cannot be undone.')) {
      alert('In a production app, this would delete all stored health data.');
    }
  };

  const handleExportData = () => {
    alert('In a production app, this would export all your data in a portable format.');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Settings</h1>
        <p className="text-gray-600">Manage your preferences and data privacy</p>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-6">
            <Shield className="w-6 h-6 text-teal-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Privacy & Data</h2>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between pb-6 border-b">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Enable Data Collection</h3>
                <p className="text-sm text-gray-600">
                  Allow the app to collect and analyze your health data for assessments
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-4">
                <input
                  type="checkbox"
                  checked={dataCollection}
                  onChange={(e) => setDataCollection(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-teal-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-teal-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between pb-6 border-b">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Automatic Backup</h3>
                <p className="text-sm text-gray-600">
                  Automatically backup your health data to secure cloud storage
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-4">
                <input
                  type="checkbox"
                  checked={autoBackup}
                  onChange={(e) => setAutoBackup(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-teal-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-teal-600"></div>
              </label>
            </div>

            <button
              onClick={handleExportData}
              className="w-full py-3 bg-teal-50 text-teal-700 rounded-lg font-semibold hover:bg-teal-100 transition-all flex items-center justify-center"
            >
              <Database className="w-5 h-5 mr-2" />
              Export My Data
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-6">
            <Bell className="w-6 h-6 text-blue-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Notifications</h2>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between pb-6 border-b">
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 mb-1">Health Reminders</h3>
                <p className="text-sm text-gray-600">
                  Receive reminders to complete regular health assessments
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer ml-4">
                <input
                  type="checkbox"
                  checked={notifications}
                  onChange={(e) => setNotifications(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>

            <div className="bg-blue-50 rounded-lg p-4">
              <p className="text-sm text-gray-700">
                <strong>Note:</strong> Browser notifications must be enabled in your system settings.
                We recommend weekly assessments for optimal health monitoring.
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-6">
            <User className="w-6 h-6 text-purple-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">Account</h2>
          </div>

          <div className="space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">User ID</div>
              <div className="font-mono text-sm text-gray-900">anonymous-user-{Math.random().toString(36).substring(7)}</div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">Member Since</div>
              <div className="text-sm text-gray-900">{new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center mb-6">
            <Info className="w-6 h-6 text-gray-600 mr-2" />
            <h2 className="text-xl font-semibold text-gray-900">About</h2>
          </div>

          <div className="space-y-4">
            <div className="text-sm text-gray-700">
              <strong>NeuroDetect AI</strong> is an AI-powered health monitoring system designed to help with
              early detection of neurodegenerative diseases through voice, facial, and typing pattern analysis.
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-gray-600 mb-1">Version</div>
                <div className="font-semibold text-gray-900">1.0.0</div>
              </div>
              <div>
                <div className="text-gray-600 mb-1">Last Updated</div>
                <div className="font-semibold text-gray-900">Oct 2025</div>
              </div>
            </div>

            <div className="pt-4 border-t">
              <button className="text-teal-600 hover:text-teal-700 font-semibold text-sm">
                Privacy Policy
              </button>
              <span className="text-gray-400 mx-2">•</span>
              <button className="text-teal-600 hover:text-teal-700 font-semibold text-sm">
                Terms of Service
              </button>
              <span className="text-gray-400 mx-2">•</span>
              <button className="text-teal-600 hover:text-teal-700 font-semibold text-sm">
                Contact Support
              </button>
            </div>
          </div>
        </div>

        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-6">
          <div className="flex items-center mb-4">
            <Trash2 className="w-6 h-6 text-red-600 mr-2" />
            <h2 className="text-xl font-semibold text-red-900">Danger Zone</h2>
          </div>

          <p className="text-sm text-red-700 mb-4">
            Deleting your data will permanently remove all health assessments, reports, and analysis history.
            This action cannot be undone.
          </p>

          <button
            onClick={handleDeleteData}
            className="w-full py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-all flex items-center justify-center"
          >
            <Trash2 className="w-5 h-5 mr-2" />
            Delete All My Data
          </button>
        </div>
      </div>
    </div>
  );
}
