import { useState, useRef, useEffect } from 'react';
import { Keyboard, Loader2, CheckCircle2, RotateCcw } from 'lucide-react';
import { TypingAnalysis } from '../types';
import { analyzeTyping } from '../utils/mockAnalysis';

interface TypingTestProps {
  onAnalysisComplete: (data: TypingAnalysis) => void;
}

const sampleTexts = [
  "The quick brown fox jumps over the lazy dog. This sentence contains every letter of the alphabet.",
  "Early detection of neurodegenerative diseases can significantly improve treatment outcomes and quality of life.",
  "Motor coordination and typing patterns can reveal subtle changes in neurological function over time.",
];

export default function TypingTest({ onAnalysisComplete }: TypingTestProps) {
  const [isTestActive, setIsTestActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [typedText, setTypedText] = useState('');
  const [currentText] = useState(sampleTexts[Math.floor(Math.random() * sampleTexts.length)]);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [analysis, setAnalysis] = useState<TypingAnalysis | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isTestActive && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [isTestActive]);

  const startTest = () => {
    setIsTestActive(true);
    setStartTime(Date.now());
    setTypedText('');
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setTypedText(e.target.value);
  };

  const finishTest = async () => {
    if (!startTime) return;

    const timeElapsed = (Date.now() - startTime) / 1000;
    setIsAnalyzing(true);

    try {
      const result = await analyzeTyping(typedText, timeElapsed);
      setAnalysis(result);
      onAnalysisComplete(result);
      setIsTestActive(false);
    } catch (err) {
      console.error('Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetTest = () => {
    setIsTestActive(false);
    setTypedText('');
    setStartTime(null);
    setAnalysis(null);
  };

  const calculateProgress = () => {
    if (!typedText || !currentText) return 0;
    return Math.min((typedText.length / currentText.length) * 100, 100);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Typing Analysis</h1>
        <p className="text-gray-600">Assess motor coordination through typing patterns and speed</p>
      </div>

      <div className="bg-white rounded-xl shadow-md p-8">
        {!isTestActive && !analysis && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-32 h-32 bg-purple-100 rounded-full mb-6">
                <Keyboard className="w-16 h-16 text-purple-600" />
              </div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Ready to Begin</h2>
              <p className="text-gray-600">Test your typing speed and accuracy</p>
            </div>

            <div className="bg-purple-50 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Instructions:</h3>
              <ol className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <span className="text-purple-600 font-bold mr-2">1.</span>
                  <span>Click "Start Test" to begin</span>
                </li>
                <li className="flex items-start">
                  <span className="text-purple-600 font-bold mr-2">2.</span>
                  <span>Type the displayed text as accurately as possible</span>
                </li>
                <li className="flex items-start">
                  <span className="text-purple-600 font-bold mr-2">3.</span>
                  <span>Maintain your natural typing rhythm</span>
                </li>
                <li className="flex items-start">
                  <span className="text-purple-600 font-bold mr-2">4.</span>
                  <span>Click "Finish Test" when complete</span>
                </li>
              </ol>
            </div>

            <button
              onClick={startTest}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-semibold hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              <span className="flex items-center justify-center">
                <Keyboard className="w-5 h-5 mr-2" />
                Start Test
              </span>
            </button>
          </div>
        )}

        {isTestActive && (
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-lg p-6">
              <h3 className="font-semibold text-gray-900 mb-3">Type this text:</h3>
              <p className="text-lg text-gray-700 leading-relaxed font-mono">{currentText}</p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold text-gray-700">Your typing:</label>
                <div className="text-sm text-gray-600">
                  Progress: {Math.round(calculateProgress())}%
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div
                  className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full transition-all"
                  style={{ width: `${calculateProgress()}%` }}
                />
              </div>
              <textarea
                ref={textareaRef}
                value={typedText}
                onChange={handleTextChange}
                className="w-full h-40 p-4 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none text-lg font-mono resize-none"
                placeholder="Start typing here..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={resetTest}
                className="py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={finishTest}
                disabled={isAnalyzing || typedText.length < 10}
                className={`py-3 rounded-xl font-semibold text-white transition-all ${
                  isAnalyzing || typedText.length < 10
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg'
                }`}
              >
                {isAnalyzing ? (
                  <span className="flex items-center justify-center">
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing...
                  </span>
                ) : (
                  'Finish Test'
                )}
              </button>
            </div>
          </div>
        )}

        {analysis && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Analysis Results</h3>

              <div className="grid md:grid-cols-3 gap-4 mb-6">
                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Typing Score</div>
                  <div className={`text-4xl font-bold ${
                    analysis.score >= 85 ? 'text-green-600' :
                    analysis.score >= 70 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {analysis.score}
                  </div>
                  <div className="text-sm text-gray-500">out of 100</div>
                </div>

                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Speed (WPM)</div>
                  <div className="text-4xl font-bold text-gray-900">{analysis.wpm}</div>
                  <div className="text-sm text-gray-500">words per minute</div>
                </div>

                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Accuracy</div>
                  <div className="text-4xl font-bold text-gray-900">{analysis.accuracy}%</div>
                  <div className="text-sm text-gray-500">correct characters</div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-3">Key Indicators:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Consistent typing rhythm detected
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Motor coordination within normal range
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    No significant delays or hesitations
                  </li>
                </ul>
              </div>
            </div>

            <button
              onClick={resetTest}
              className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl font-semibold hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              <span className="flex items-center justify-center">
                <RotateCcw className="w-5 h-5 mr-2" />
                Take Another Test
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
