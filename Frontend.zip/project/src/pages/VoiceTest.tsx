import { useState, useRef } from 'react';
import { Mic, Square, Play, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { VoiceAnalysis } from '../types';
import { analyzeVoice } from '../utils/mockAnalysis';

interface VoiceTestProps {
  onAnalysisComplete: (data: VoiceAnalysis) => void;
}

export default function VoiceTest({ onAnalysisComplete }: VoiceTestProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [hasRecording, setHasRecording] = useState(false);
  const [analysis, setAnalysis] = useState<VoiceAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<number | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);
      setHasRecording(false);

      timerRef.current = window.setInterval(() => {
        setRecordingTime((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      setError('Could not access microphone. Please grant permission and try again.');
      console.error('Error accessing microphone:', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
      setIsRecording(false);
      setHasRecording(true);

      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  };

  const analyzeRecording = async () => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeVoice(recordingTime);
      setAnalysis(result);
      onAnalysisComplete(result);
    } catch (err) {
      setError('Analysis failed. Please try again.');
      console.error('Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetTest = () => {
    setHasRecording(false);
    setAnalysis(null);
    setRecordingTime(0);
    setError(null);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Voice Analysis</h1>
        <p className="text-gray-600">Record your voice to analyze speech patterns and vocal health</p>
      </div>

      <div className="bg-white rounded-xl shadow-md p-8">
        <div className="text-center mb-8">
          <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full mb-6 transition-all ${
            isRecording
              ? 'bg-red-100 animate-pulse'
              : 'bg-teal-100'
          }`}>
            <Mic className={`w-16 h-16 ${isRecording ? 'text-red-600' : 'text-teal-600'}`} />
          </div>

          {isRecording && (
            <div className="mb-6">
              <div className="text-4xl font-bold text-gray-900 mb-2">{formatTime(recordingTime)}</div>
              <p className="text-gray-600">Recording in progress...</p>
            </div>
          )}

          {hasRecording && !analysis && (
            <div className="mb-6">
              <div className="flex items-center justify-center text-green-600 mb-2">
                <CheckCircle2 className="w-6 h-6 mr-2" />
                <span className="font-semibold">Recording complete ({formatTime(recordingTime)})</span>
              </div>
              <p className="text-gray-600">Ready to analyze</p>
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 bg-red-50 rounded-lg flex items-center text-red-700">
              <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}
        </div>

        {!isRecording && !hasRecording && !analysis && (
          <div className="space-y-4">
            <div className="bg-blue-50 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Instructions:</h3>
              <ol className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <span className="text-teal-600 font-bold mr-2">1.</span>
                  <span>Find a quiet environment with minimal background noise</span>
                </li>
                <li className="flex items-start">
                  <span className="text-teal-600 font-bold mr-2">2.</span>
                  <span>Click the "Start Recording" button below</span>
                </li>
                <li className="flex items-start">
                  <span className="text-teal-600 font-bold mr-2">3.</span>
                  <span>Read the following sentence clearly: "The quick brown fox jumps over the lazy dog"</span>
                </li>
                <li className="flex items-start">
                  <span className="text-teal-600 font-bold mr-2">4.</span>
                  <span>Count from 1 to 10 at a natural pace</span>
                </li>
                <li className="flex items-start">
                  <span className="text-teal-600 font-bold mr-2">5.</span>
                  <span>Click "Stop Recording" when finished</span>
                </li>
              </ol>
            </div>

            <button
              onClick={startRecording}
              className="w-full py-4 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-xl font-semibold hover:from-teal-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              <span className="flex items-center justify-center">
                <Mic className="w-5 h-5 mr-2" />
                Start Recording
              </span>
            </button>
          </div>
        )}

        {isRecording && (
          <button
            onClick={stopRecording}
            className="w-full py-4 bg-red-600 text-white rounded-xl font-semibold hover:bg-red-700 shadow-lg hover:shadow-xl transition-all"
          >
            <span className="flex items-center justify-center">
              <Square className="w-5 h-5 mr-2" />
              Stop Recording
            </span>
          </button>
        )}

        {hasRecording && !analysis && (
          <div className="space-y-4">
            <button
              onClick={analyzeRecording}
              disabled={isAnalyzing}
              className={`w-full py-4 rounded-xl font-semibold text-white transition-all ${
                isAnalyzing
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
              }`}
            >
              {isAnalyzing ? (
                <span className="flex items-center justify-center">
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Analyzing Voice Patterns...
                </span>
              ) : (
                <span className="flex items-center justify-center">
                  <Play className="w-5 h-5 mr-2" />
                  Analyze Recording
                </span>
              )}
            </button>

            <button
              onClick={resetTest}
              className="w-full py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
            >
              Record Again
            </button>
          </div>
        )}

        {analysis && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-teal-50 to-blue-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Analysis Results</h3>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Voice Health Score</div>
                  <div className={`text-4xl font-bold ${
                    analysis.score >= 85 ? 'text-green-600' :
                    analysis.score >= 70 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {analysis.score}
                  </div>
                  <div className="text-sm text-gray-500">out of 100</div>
                </div>

                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Recording Duration</div>
                  <div className="text-4xl font-bold text-gray-900">{analysis.duration}s</div>
                  <div className="text-sm text-gray-500">total length</div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-3">Key Indicators:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Speech clarity within normal range
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Voice stability detected
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    No significant tremors identified
                  </li>
                </ul>
              </div>
            </div>

            <button
              onClick={resetTest}
              className="w-full py-4 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-xl font-semibold hover:from-teal-700 hover:to-blue-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              Take Another Test
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
