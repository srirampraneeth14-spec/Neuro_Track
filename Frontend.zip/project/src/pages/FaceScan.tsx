import { useState, useRef, useEffect } from 'react';
import { Camera, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { FaceAnalysis } from '../types';
import { analyzeFace } from '../utils/mockAnalysis';

interface FaceScanProps {
  onAnalysisComplete: (data: FaceAnalysis) => void;
}

export default function FaceScan({ onAnalysisComplete }: FaceScanProps) {
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<FaceAnalysis | null>(null);
  const [error, setError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startCamera = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 1280, height: 720 }
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      setIsCameraActive(true);
    } catch (err) {
      setError('Could not access camera. Please grant permission and try again.');
      console.error('Error accessing camera:', err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const captureSnapshot = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        const imageData = canvas.toDataURL('image/jpeg');
        setCapturedImage(imageData);
        stopCamera();
      }
    }
  };

  const analyzeSnapshot = async () => {
    setIsAnalyzing(true);
    try {
      const result = await analyzeFace();
      setAnalysis(result);
      onAnalysisComplete(result);
    } catch (err) {
      setError('Analysis failed. Please try again.');
      console.error('Analysis error:', err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetScan = () => {
    setCapturedImage(null);
    setAnalysis(null);
    setError(null);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Facial Expression Analysis</h1>
        <p className="text-gray-600">Capture your facial expressions for neurological health assessment</p>
      </div>

      <div className="bg-white rounded-xl shadow-md p-8">
        {!isCameraActive && !capturedImage && !analysis && (
          <div className="space-y-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-32 h-32 bg-blue-100 rounded-full mb-6">
                <Camera className="w-16 h-16 text-blue-600" />
              </div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Ready to Scan</h2>
              <p className="text-gray-600">Position your face in the camera frame</p>
            </div>

            {error && (
              <div className="mb-6 p-4 bg-red-50 rounded-lg flex items-center text-red-700">
                <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0" />
                <p className="text-sm">{error}</p>
              </div>
            )}

            <div className="bg-blue-50 rounded-lg p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-3">Instructions:</h3>
              <ol className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-2">1.</span>
                  <span>Ensure good lighting on your face</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-2">2.</span>
                  <span>Look directly at the camera</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-2">3.</span>
                  <span>Maintain a neutral, relaxed expression</span>
                </li>
                <li className="flex items-start">
                  <span className="text-blue-600 font-bold mr-2">4.</span>
                  <span>Click "Capture" when ready</span>
                </li>
              </ol>
            </div>

            <button
              onClick={startCamera}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-teal-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              <span className="flex items-center justify-center">
                <Camera className="w-5 h-5 mr-2" />
                Start Camera
              </span>
            </button>
          </div>
        )}

        {isCameraActive && (
          <div className="space-y-6">
            <div className="relative bg-black rounded-xl overflow-hidden">
              <video
                ref={videoRef}
                className="w-full h-auto transform scale-x-[-1]"
                autoPlay
                playsInline
                muted
              />
              <div className="absolute inset-0 border-4 border-blue-500 rounded-xl pointer-events-none" />
              <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse" />
                Live
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={stopCamera}
                className="py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={captureSnapshot}
                className="py-3 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-teal-700 shadow-lg transition-all"
              >
                <span className="flex items-center justify-center">
                  <Camera className="w-5 h-5 mr-2" />
                  Capture
                </span>
              </button>
            </div>
          </div>
        )}

        {capturedImage && !analysis && (
          <div className="space-y-6">
            <div className="relative bg-gray-100 rounded-xl overflow-hidden">
              <img
                src={capturedImage}
                alt="Captured face"
                className="w-full h-auto transform scale-x-[-1]"
              />
              <div className="absolute top-4 right-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                <CheckCircle2 className="w-4 h-4 mr-1" />
                Captured
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={resetScan}
                className="py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
              >
                Retake
              </button>
              <button
                onClick={analyzeSnapshot}
                disabled={isAnalyzing}
                className={`py-3 rounded-xl font-semibold text-white transition-all ${
                  isAnalyzing
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 shadow-lg'
                }`}
              >
                {isAnalyzing ? (
                  <span className="flex items-center justify-center">
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing...
                  </span>
                ) : (
                  'Analyze'
                )}
              </button>
            </div>
          </div>
        )}

        {analysis && (
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-blue-50 to-teal-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Analysis Results</h3>

              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Facial Health Score</div>
                  <div className={`text-4xl font-bold ${
                    analysis.score >= 85 ? 'text-green-600' :
                    analysis.score >= 70 ? 'text-yellow-600' :
                    'text-red-600'
                  }`}>
                    {analysis.score}
                  </div>
                  <div className="text-sm text-gray-500">out of 100</div>
                </div>

                <div className="bg-white rounded-lg p-4">
                  <div className="text-sm text-gray-600 mb-1">Detected Expression</div>
                  <div className="text-2xl font-bold text-gray-900">{analysis.expression}</div>
                  <div className="text-sm text-gray-500">primary emotion</div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-3">Key Findings:</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Facial symmetry within normal parameters
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Eye movement patterns are healthy
                  </li>
                  <li className="flex items-center">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mr-2" />
                    Muscle control appears normal
                  </li>
                </ul>
              </div>
            </div>

            {capturedImage && (
              <div className="bg-gray-50 rounded-xl p-4">
                <h4 className="font-semibold text-gray-900 mb-3">Captured Snapshot:</h4>
                <img
                  src={capturedImage}
                  alt="Analysis snapshot"
                  className="w-full h-auto rounded-lg transform scale-x-[-1]"
                />
              </div>
            )}

            <button
              onClick={resetScan}
              className="w-full py-4 bg-gradient-to-r from-blue-600 to-teal-600 text-white rounded-xl font-semibold hover:from-blue-700 hover:to-teal-700 shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
            >
              Take Another Scan
            </button>
          </div>
        )}

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
}
