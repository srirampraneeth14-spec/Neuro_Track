import { useState } from 'react';
import { Mic, Camera, TrendingUp, Activity, Loader2, Keyboard } from 'lucide-react';
import DashboardCard from '../components/DashboardCard';
import { VoiceAnalysis, FaceAnalysis, TypingAnalysis, RiskLevel } from '../types';
import { analyzeVoice, analyzeFace, calculateRiskLevel, getRiskColor, generateMockTrendData } from '../utils/mockAnalysis';

interface DashboardProps {
  voiceData: VoiceAnalysis | null;
  faceData: FaceAnalysis | null;
  typingData: TypingAnalysis | null;
  onVoiceUpdate: (data: VoiceAnalysis) => void;
  onFaceUpdate: (data: FaceAnalysis) => void;
}

export default function Dashboard({ voiceData, faceData, typingData, onVoiceUpdate, onFaceUpdate }: DashboardProps) {
  const [isScanning, setIsScanning] = useState(false);
  const trendData = generateMockTrendData();

  const riskLevel: RiskLevel = voiceData && faceData && typingData
    ? calculateRiskLevel(voiceData.score, faceData.score, typingData.score)
    : 'Low';

  const avgScore = voiceData && faceData && typingData
    ? Math.round((voiceData.score + faceData.score + typingData.score) / 3)
    : null;

  const handleQuickScan = async () => {
    setIsScanning(true);
    try {
      const [voice, face] = await Promise.all([
        analyzeVoice(3),
        analyzeFace(),
      ]);
      onVoiceUpdate(voice);
      onFaceUpdate(face);
    } catch (error) {
      console.error('Quick scan failed:', error);
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 pb-24 md:pb-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Health Dashboard</h1>
        <p className="text-gray-600">Monitor your neurological health indicators</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <DashboardCard
          title="Voice Health"
          score={voiceData?.score || null}
          icon={Mic}
          color="text-teal-600"
          subtitle="Acoustic analysis"
        />
        <DashboardCard
          title="Facial Expression"
          score={faceData?.score || null}
          icon={Camera}
          color="text-blue-600"
          subtitle="Expression tracking"
        />
        <DashboardCard
          title="Typing Patterns"
          score={typingData?.score || null}
          icon={Keyboard}
          color="text-purple-600"
          subtitle="Motor coordination"
        />
      </div>

      <div className="bg-white rounded-xl shadow-md p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-1">Combined Risk Assessment</h2>
            <p className="text-sm text-gray-600">Based on all available metrics</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {avgScore !== null ? avgScore : '--'}
            </div>
            <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold ${
              riskLevel === 'Low' ? 'bg-green-100 text-green-800' :
              riskLevel === 'Moderate' ? 'bg-yellow-100 text-yellow-800' :
              'bg-red-100 text-red-800'
            }`}>
              {riskLevel} Risk
            </div>
          </div>
        </div>

        <div className="mb-4">
          <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
            <span>Overall Health Score</span>
            <span>{avgScore !== null ? `${avgScore}/100` : 'No data'}</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 ${avgScore !== null ? getRiskColor(riskLevel) : 'bg-gray-300'}`}
              style={{ width: `${avgScore || 0}%` }}
            />
          </div>
        </div>

        <button
          onClick={handleQuickScan}
          disabled={isScanning}
          className={`w-full py-4 rounded-xl font-semibold text-white transition-all ${
            isScanning
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-teal-600 to-blue-600 hover:from-teal-700 hover:to-blue-700 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5'
          }`}
        >
          {isScanning ? (
            <span className="flex items-center justify-center">
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Running Quick Scan...
            </span>
          ) : (
            <span className="flex items-center justify-center">
              <Activity className="w-5 h-5 mr-2" />
              Quick Scan (Voice + Face)
            </span>
          )}
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center mb-6">
          <TrendingUp className="w-6 h-6 text-teal-600 mr-2" />
          <h2 className="text-xl font-semibold text-gray-900">Weekly Health Trend</h2>
        </div>

        <div className="flex items-end justify-between h-48 gap-2">
          {trendData.map((data, index) => (
            <div key={index} className="flex-1 flex flex-col items-center">
              <div className="w-full bg-gray-100 rounded-t-lg relative" style={{ height: '100%' }}>
                <div
                  className="absolute bottom-0 w-full bg-gradient-to-t from-teal-500 to-blue-500 rounded-t-lg transition-all"
                  style={{ height: `${data.score}%` }}
                />
              </div>
              <div className="text-xs text-gray-600 mt-2 font-medium">{data.day}</div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Average this week</span>
            <span className="font-semibold text-gray-900">
              {Math.round(trendData.reduce((acc, d) => acc + d.score, 0) / trendData.length)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
