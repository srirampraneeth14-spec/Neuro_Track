import { useState, useEffect } from 'react';
import ConsentScreen from './components/ConsentScreen';
import Navigation from './components/Navigation';
import Dashboard from './pages/Dashboard';
import VoiceTest from './pages/VoiceTest';
import FaceScan from './pages/FaceScan';
import TypingTest from './pages/TypingTest';
import Reports from './pages/Reports';
import Settings from './pages/Settings';
import { VoiceAnalysis, FaceAnalysis, TypingAnalysis } from './types';

function App() {
  const [hasConsented, setHasConsented] = useState(false);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [voiceData, setVoiceData] = useState<VoiceAnalysis | null>(null);
  const [faceData, setFaceData] = useState<FaceAnalysis | null>(null);
  const [typingData, setTypingData] = useState<TypingAnalysis | null>(null);

  useEffect(() => {
    const consent = localStorage.getItem('neurodetect_consent');
    if (consent === 'true') {
      setHasConsented(true);
    }

    const savedVoice = localStorage.getItem('neurodetect_voice');
    const savedFace = localStorage.getItem('neurodetect_face');
    const savedTyping = localStorage.getItem('neurodetect_typing');

    if (savedVoice) setVoiceData(JSON.parse(savedVoice));
    if (savedFace) setFaceData(JSON.parse(savedFace));
    if (savedTyping) setTypingData(JSON.parse(savedTyping));
  }, []);

  const handleConsent = () => {
    localStorage.setItem('neurodetect_consent', 'true');
    setHasConsented(true);
  };

  const handleVoiceUpdate = (data: VoiceAnalysis) => {
    setVoiceData(data);
    localStorage.setItem('neurodetect_voice', JSON.stringify(data));
  };

  const handleFaceUpdate = (data: FaceAnalysis) => {
    setFaceData(data);
    localStorage.setItem('neurodetect_face', JSON.stringify(data));
  };

  const handleTypingUpdate = (data: TypingAnalysis) => {
    setTypingData(data);
    localStorage.setItem('neurodetect_typing', JSON.stringify(data));
  };

  if (!hasConsented) {
    return <ConsentScreen onConsent={handleConsent} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Navigation currentPage={currentPage} onNavigate={setCurrentPage} />

      <main>
        {currentPage === 'dashboard' && (
          <Dashboard
            voiceData={voiceData}
            faceData={faceData}
            typingData={typingData}
            onVoiceUpdate={handleVoiceUpdate}
            onFaceUpdate={handleFaceUpdate}
          />
        )}
        {currentPage === 'voice' && <VoiceTest onAnalysisComplete={handleVoiceUpdate} />}
        {currentPage === 'face' && <FaceScan onAnalysisComplete={handleFaceUpdate} />}
        {currentPage === 'typing' && <TypingTest onAnalysisComplete={handleTypingUpdate} />}
        {currentPage === 'reports' && (
          <Reports voiceData={voiceData} faceData={faceData} typingData={typingData} />
        )}
        {currentPage === 'settings' && <Settings />}
      </main>
    </div>
  );
}

export default App;
