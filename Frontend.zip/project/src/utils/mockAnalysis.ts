import { VoiceAnalysis, FaceAnalysis, TypingAnalysis, RiskLevel } from '../types';

export const analyzeVoice = async (duration: number): Promise<VoiceAnalysis> => {
  await new Promise(resolve => setTimeout(resolve, 2000));

  const score = Math.floor(Math.random() * 30) + 70;

  return {
    id: crypto.randomUUID(),
    score,
    duration,
    timestamp: new Date(),
  };
};

export const analyzeFace = async (): Promise<FaceAnalysis> => {
  await new Promise(resolve => setTimeout(resolve, 2000));

  const expressions = ['Neutral', 'Slight Smile', 'Focused', 'Relaxed', 'Attentive'];
  const score = Math.floor(Math.random() * 30) + 70;

  return {
    id: crypto.randomUUID(),
    score,
    expression: expressions[Math.floor(Math.random() * expressions.length)],
    timestamp: new Date(),
  };
};

export const analyzeTyping = async (text: string, timeElapsed: number): Promise<TypingAnalysis> => {
  await new Promise(resolve => setTimeout(resolve, 1500));

  const words = text.trim().split(/\s+/).length;
  const wpm = Math.round((words / timeElapsed) * 60);
  const accuracy = Math.floor(Math.random() * 10) + 90;
  const score = Math.floor(Math.random() * 30) + 70;

  return {
    id: crypto.randomUUID(),
    score,
    wpm,
    accuracy,
    timestamp: new Date(),
  };
};

export const calculateRiskLevel = (voiceScore: number, faceScore: number, typingScore: number): RiskLevel => {
  const avgScore = (voiceScore + faceScore + typingScore) / 3;

  if (avgScore >= 85) return 'Low';
  if (avgScore >= 70) return 'Moderate';
  return 'High';
};

export const getRiskColor = (risk: RiskLevel): string => {
  switch (risk) {
    case 'Low':
      return 'bg-green-500';
    case 'Moderate':
      return 'bg-yellow-500';
    case 'High':
      return 'bg-red-500';
  }
};

export const generateMockTrendData = () => {
  return Array.from({ length: 7 }, (_, i) => ({
    day: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][i],
    score: Math.floor(Math.random() * 20) + 75,
  }));
};
