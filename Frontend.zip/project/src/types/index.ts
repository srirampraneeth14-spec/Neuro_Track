export interface VoiceAnalysis {
  id: string;
  score: number;
  duration: number;
  timestamp: Date;
  audioUrl?: string;
}

export interface FaceAnalysis {
  id: string;
  score: number;
  expression: string;
  timestamp: Date;
  snapshotUrl?: string;
}

export interface TypingAnalysis {
  id: string;
  score: number;
  wpm: number;
  accuracy: number;
  timestamp: Date;
}

export interface HealthReport {
  id: string;
  date: Date;
  voiceScore: number;
  faceScore: number;
  typingScore: number;
  riskLevel: 'Low' | 'Moderate' | 'High';
  recommendations: string[];
}

export type RiskLevel = 'Low' | 'Moderate' | 'High';
