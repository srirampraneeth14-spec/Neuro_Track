export type RiskLevel = 'low' | 'moderate' | 'high';
export type AssessmentType = 'voice' | 'face' | 'typing' | 'combined';
export type AssessmentStatus = 'in_progress' | 'completed' | 'failed';
export type ConsultationStatus = 'requested' | 'scheduled' | 'completed' | 'cancelled';

export interface Profile {
  id: string;
  full_name: string;
  date_of_birth?: string;
  phone?: string;
  emergency_contact?: string;
  medical_history?: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Assessment {
  id: string;
  user_id: string;
  assessment_type: AssessmentType;
  status: AssessmentStatus;
  consent_given: boolean;
  started_at: string;
  completed_at?: string;
  created_at: string;
}

export interface AssessmentResult {
  id: string;
  assessment_id: string;
  risk_score: number;
  risk_level: RiskLevel;
  analysis_data: {
    voice?: {
      pitch_variation: number;
      speech_rate: number;
      pause_frequency: number;
      emotional_tone: string;
    };
    face?: {
      symmetry_score: number;
      micro_expressions: number;
      eye_movement: number;
      facial_tension: number;
    };
    typing?: {
      average_speed: number;
      error_rate: number;
      pause_patterns: number;
      rhythm_consistency: number;
    };
  };
  recommendations: string[];
  created_at: string;
}

export interface Consultation {
  id: string;
  user_id: string;
  assessment_id?: string;
  status: ConsultationStatus;
  scheduled_at?: string;
  doctor_name?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface ConsultationMessage {
  id: string;
  consultation_id: string;
  sender_id: string;
  message: string;
  created_at: string;
}

export interface TrendData {
  date: string;
  risk_score: number;
}
