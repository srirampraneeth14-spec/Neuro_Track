import { AssessmentType, RiskLevel } from '../types';

export const generateMockAnalysis = (assessmentType: AssessmentType) => {
  const riskScore = Math.floor(Math.random() * 100);
  const riskLevel: RiskLevel =
    riskScore < 30 ? 'low' :
    riskScore < 70 ? 'moderate' :
    'high';

  const baseAnalysis: any = {};
  const recommendations: string[] = [];

  if (assessmentType === 'voice' || assessmentType === 'combined') {
    baseAnalysis.voice = {
      pitch_variation: Math.random() * 100,
      speech_rate: 120 + Math.random() * 60,
      pause_frequency: Math.random() * 10,
      emotional_tone: ['calm', 'neutral', 'stressed', 'anxious'][Math.floor(Math.random() * 4)]
    };
    recommendations.push('Consider regular vocal exercises to maintain speech patterns');
  }

  if (assessmentType === 'face' || assessmentType === 'combined') {
    baseAnalysis.face = {
      symmetry_score: 70 + Math.random() * 30,
      micro_expressions: Math.random() * 100,
      eye_movement: Math.random() * 100,
      facial_tension: Math.random() * 100
    };
    recommendations.push('Facial relaxation techniques may help reduce tension');
  }

  if (assessmentType === 'typing' || assessmentType === 'combined') {
    baseAnalysis.typing = {
      average_speed: 40 + Math.random() * 80,
      error_rate: Math.random() * 10,
      pause_patterns: Math.random() * 100,
      rhythm_consistency: 60 + Math.random() * 40
    };
    recommendations.push('Regular cognitive exercises can improve typing consistency');
  }

  if (riskLevel === 'high') {
    recommendations.push('We recommend scheduling a consultation with a healthcare professional');
    recommendations.push('Consider a comprehensive neurological assessment');
  } else if (riskLevel === 'moderate') {
    recommendations.push('Monitor symptoms and repeat assessment in 30 days');
    recommendations.push('Maintain healthy sleep and stress management practices');
  } else {
    recommendations.push('Continue with regular health monitoring');
    recommendations.push('Maintain current lifestyle and wellness practices');
  }

  return {
    risk_score: riskScore,
    risk_level: riskLevel,
    analysis_data: baseAnalysis,
    recommendations
  };
};

export const simulateProcessingDelay = (seconds: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, seconds * 1000));
};
