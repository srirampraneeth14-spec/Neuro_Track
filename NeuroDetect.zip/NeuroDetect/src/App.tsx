import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { Dashboard } from './components/Dashboard';
import { AssessmentFlow } from './components/AssessmentFlow';
import { ReportView } from './components/ReportView';
import { Consultations } from './components/Consultations';
import { Loader2, LogOut } from 'lucide-react';
import { AssessmentType } from './types';

type View = 'dashboard' | 'assessment' | 'report' | 'consultations';

const AppContent = () => {
  const { user, profile, loading, signOut } = useAuth();
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [selectedAssessmentType, setSelectedAssessmentType] = useState<AssessmentType>('voice');
  const [selectedReportId, setSelectedReportId] = useState<string>('');
  const [preselectedAssessmentId, setPreselectedAssessmentId] = useState<string | undefined>();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen />;
  }

  const handleStartAssessment = (type: string) => {
    setSelectedAssessmentType(type as AssessmentType);
    setCurrentView('assessment');
  };

  const handleAssessmentComplete = () => {
    setCurrentView('dashboard');
  };

  const handleViewReport = (assessmentId: string) => {
    setSelectedReportId(assessmentId);
    setCurrentView('report');
  };

  const handleViewConsultations = () => {
    setPreselectedAssessmentId(undefined);
    setCurrentView('consultations');
  };

  const handleRequestConsultation = (assessmentId: string) => {
    setPreselectedAssessmentId(assessmentId);
    setCurrentView('consultations');
  };

  const handleBackToDashboard = () => {
    setCurrentView('dashboard');
    setPreselectedAssessmentId(undefined);
  };

  const handleSignOut = async () => {
    await signOut();
    setCurrentView('dashboard');
  };

  return (
    <div className="min-h-screen">
      {currentView === 'dashboard' && (
        <>
          <div className="bg-white border-b border-gray-200 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-blue-600 p-2 rounded-lg">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <div>
                    <h1 className="text-xl font-bold text-gray-900">NeuroDetect AI</h1>
                    <p className="text-xs text-gray-600">Advanced Health Screening</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right hidden sm:block">
                    <p className="text-sm font-semibold text-gray-900">{profile?.full_name}</p>
                    <p className="text-xs text-gray-600">{user.email}</p>
                  </div>
                  <button
                    onClick={handleSignOut}
                    className="flex items-center gap-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 px-3 py-2 rounded-lg transition-colors"
                    title="Sign out"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
          <Dashboard
            onStartAssessment={handleStartAssessment}
            onViewReport={handleViewReport}
            onViewConsultations={handleViewConsultations}
          />
        </>
      )}

      {currentView === 'assessment' && (
        <AssessmentFlow
          assessmentType={selectedAssessmentType}
          onComplete={handleAssessmentComplete}
        />
      )}

      {currentView === 'report' && (
        <ReportView
          assessmentId={selectedReportId}
          onBack={handleBackToDashboard}
          onRequestConsultation={handleRequestConsultation}
        />
      )}

      {currentView === 'consultations' && (
        <Consultations
          onBack={handleBackToDashboard}
          preselectedAssessmentId={preselectedAssessmentId}
        />
      )}
    </div>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
