import { useState, useRef, useEffect } from 'react';
import { Keyboard, Loader2, CheckCircle } from 'lucide-react';

interface TypingAnalysisProps {
  onComplete: (keystrokeData: any) => void;
}

export const TypingAnalysis = ({ onComplete }: TypingAnalysisProps) => {
  const [text, setText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [keystrokeTimes, setKeystrokeTimes] = useState<number[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const targetText = "The advancement of artificial intelligence and machine learning technologies has revolutionized healthcare. Early detection systems can now identify patterns that might indicate neurological conditions, helping doctors provide better care to patients around the world.";

  const minChars = 50;

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, []);

  const handleKeyDown = () => {
    if (startTime === null) {
      setStartTime(Date.now());
    }
    setKeystrokeTimes(prev => [...prev, Date.now()]);
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value);
  };

  const handleSubmit = async () => {
    if (text.length < minChars) return;

    setIsProcessing(true);

    const timings = [];
    for (let i = 1; i < keystrokeTimes.length; i++) {
      timings.push(keystrokeTimes[i] - keystrokeTimes[i - 1]);
    }

    const keystrokeData = {
      text_length: text.length,
      duration_ms: startTime ? Date.now() - startTime : 0,
      keystroke_intervals: timings,
      average_interval: timings.length > 0 ? timings.reduce((a, b) => a + b, 0) / timings.length : 0,
      words_per_minute: startTime ? (text.split(/\s+/).length / ((Date.now() - startTime) / 60000)) : 0
    };

    await new Promise(resolve => setTimeout(resolve, 2000));

    setIsProcessing(false);
    setIsComplete(true);

    setTimeout(() => {
      onComplete(keystrokeData);
    }, 1000);
  };

  const progress = Math.min((text.length / minChars) * 100, 100);
  const wordsTyped = text.trim().split(/\s+/).filter(w => w.length > 0).length;
  const charsRemaining = Math.max(0, minChars - text.length);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
        <h2 className="text-3xl font-bold text-center mb-2 text-gray-900">
          Typing Pattern Analysis
        </h2>
        <p className="text-center text-gray-600 mb-8">
          Type naturally in the text area below
        </p>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-gray-700">Progress</span>
            <span className="text-sm text-gray-600">
              {text.length} / {minChars} characters
            </span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-600 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          {charsRemaining > 0 && (
            <p className="text-xs text-gray-500 mt-1">
              {charsRemaining} more characters needed to complete
            </p>
          )}
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-gray-900 mb-2 text-sm flex items-center gap-2">
            <Keyboard className="w-4 h-4" />
            Suggested Text (or type your own):
          </h4>
          <p className="text-sm text-gray-700 leading-relaxed">
            {targetText}
          </p>
        </div>

        <div className="mb-6">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            placeholder="Start typing here..."
            disabled={isProcessing || isComplete}
            className="w-full h-48 p-4 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all resize-none text-gray-900 placeholder-gray-400 disabled:bg-gray-100 disabled:cursor-not-allowed"
          />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="text-2xl font-bold text-gray-900">{wordsTyped}</div>
            <div className="text-sm text-gray-600">Words Typed</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="text-2xl font-bold text-gray-900">
              {startTime ? Math.floor((Date.now() - startTime) / 1000) : 0}s
            </div>
            <div className="text-sm text-gray-600">Time Elapsed</div>
          </div>
        </div>

        {!isProcessing && !isComplete && (
          <>
            <button
              onClick={handleSubmit}
              disabled={text.length < minChars}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02] disabled:transform-none mb-6"
            >
              {text.length < minChars
                ? `Type ${charsRemaining} more characters to continue`
                : 'Complete Analysis'}
            </button>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                Tips for accurate analysis:
              </h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Type at your normal, comfortable speed</li>
                <li>• Don't try to type faster or slower than usual</li>
                <li>• Use your typical typing style and posture</li>
                <li>• Take natural pauses while thinking</li>
              </ul>
            </div>
          </>
        )}

        {isProcessing && (
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 text-blue-600 animate-spin" />
            <p className="text-gray-600">Analyzing typing patterns...</p>
          </div>
        )}

        {isComplete && (
          <div className="flex flex-col items-center gap-4">
            <CheckCircle className="w-12 h-12 text-green-600" />
            <p className="text-green-600 font-medium">Analysis complete!</p>
          </div>
        )}
      </div>
    </div>
  );
};
