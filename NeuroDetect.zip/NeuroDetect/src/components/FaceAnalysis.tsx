import { useState, useRef, useEffect } from 'react';
import { Camera, Loader2, CheckCircle } from 'lucide-react';

interface FaceAnalysisProps {
  onComplete: () => void;
}

export const FaceAnalysis = ({ onComplete }: FaceAnalysisProps) => {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [captureCount, setCaptureCount] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const totalCaptures = 5;
  const captureInterval = 2000;

  useEffect(() => {
    startCamera();
    return () => {
      stopCamera();
    };
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user' }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setHasPermission(true);
    } catch (error) {
      console.error('Error accessing camera:', error);
      setHasPermission(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
  };

  const startCapture = async () => {
    setIsCapturing(true);
    setCaptureCount(0);

    for (let i = 0; i < totalCaptures; i++) {
      await new Promise(resolve => setTimeout(resolve, captureInterval));
      setCaptureCount(i + 1);
    }

    setIsCapturing(false);
    setIsProcessing(true);

    await new Promise(resolve => setTimeout(resolve, 2000));

    stopCamera();
    setIsProcessing(false);
    setIsComplete(true);

    setTimeout(() => {
      onComplete();
    }, 1000);
  };

  if (hasPermission === false) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <div className="bg-red-100 p-4 rounded-full inline-block mb-4">
            <Camera className="w-12 h-12 text-red-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Camera Access Required</h2>
          <p className="text-gray-600 mb-6">
            Please grant camera permission to continue with facial analysis.
          </p>
          <button
            onClick={startCamera}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors"
          >
            Enable Camera
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
        <h2 className="text-3xl font-bold text-center mb-2 text-gray-900">
          Face Analysis
        </h2>
        <p className="text-center text-gray-600 mb-8">
          Look directly at the camera and remain still
        </p>

        <div className="relative mb-8 bg-gray-900 rounded-2xl overflow-hidden aspect-video">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />

          {isCapturing && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/20">
              <div className="bg-white rounded-full p-4">
                <div className="text-4xl font-bold text-blue-600">
                  {captureCount}/{totalCaptures}
                </div>
              </div>
            </div>
          )}

          {isCapturing && (
            <div className="absolute bottom-0 left-0 right-0 h-2 bg-gray-200">
              <div
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${(captureCount / totalCaptures) * 100}%` }}
              />
            </div>
          )}

          <div className="absolute top-4 left-4 right-4">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg p-3 text-white text-sm">
              {isProcessing ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing facial features...</span>
                </div>
              ) : isComplete ? (
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>Capture complete!</span>
                </div>
              ) : isCapturing ? (
                <span>Capturing images... Hold still</span>
              ) : (
                <span>Position your face in the center</span>
              )}
            </div>
          </div>

          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-80 border-2 border-blue-500 rounded-full opacity-30"></div>
          </div>
        </div>

        {!isCapturing && !isProcessing && !isComplete && (
          <>
            <button
              onClick={startCapture}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02] mb-6"
            >
              Start Capture
            </button>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-2 text-sm">
                Capture Instructions:
              </h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Position your face in the center of the frame</li>
                <li>• Ensure good lighting on your face</li>
                <li>• Remove glasses if possible</li>
                <li>• Remain still during capture</li>
                <li>• Maintain a neutral expression</li>
              </ul>
            </div>
          </>
        )}

        {isCapturing && (
          <div className="text-center">
            <p className="text-gray-600">
              Capturing {totalCaptures} images for analysis...
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
