import { useState, useEffect } from 'react';
import {
  Activity,
  TrendingUp,
  TrendingDown,
  Mic,
  Camera,
  Keyboard,
  Calendar,
  FileText,
  Users,
  AlertCircle,
  CheckCircle,
  Clock
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Assessment, AssessmentResult, TrendData } from '../types';

interface DashboardProps {
  onStartAssessment: (type: string) => void;
  onViewReport: (assessmentId: string) => void;
  onViewConsultations: () => void;
}

export const Dashboard = ({ onStartAssessment, onViewReport, onViewConsultations }: DashboardProps) => {
  const { user, profile } = useAuth();
  const [assessments, setAssessments] = useState<(Assessment & { result?: AssessmentResult })[]>([]);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchAssessments();
    }
  }, [user]);

  const fetchAssessments = async () => {
    setLoading(true);

    const { data: assessmentsData, error: assessmentsError } = await supabase
      .from('assessments')
      .select('*')
      .eq('user_id', user!.id)
      .eq('status', 'completed')
      .order('completed_at', { ascending: false })
      .limit(10);

    if (assessmentsError) {
      console.error('Error fetching assessments:', assessmentsError);
      setLoading(false);
      return;
    }

    const assessmentsWithResults = await Promise.all(
      (assessmentsData || []).map(async (assessment) => {
        const { data: result } = await supabase
          .from('assessment_results')
          .select('*')
          .eq('assessment_id', assessment.id)
          .maybeSingle();

        return { ...assessment, result };
      })
    );

    setAssessments(assessmentsWithResults);

    const trends = assessmentsWithResults
      .filter(a => a.result)
      .map(a => ({
        date: new Date(a.completed_at!).toLocaleDateString(),
        risk_score: a.result!.risk_score
      }))
      .reverse()
      .slice(-7);

    setTrendData(trends);
    setLoading(false);
  };

  const getLatestRiskScore = () => {
    if (assessments.length > 0 && assessments[0].result) {
      return assessments[0].result.risk_score;
    }
    return null;
  };

  const getRiskTrend = () => {
    if (trendData.length < 2) return null;
    const latest = trendData[trendData.length - 1].risk_score;
    const previous = trendData[trendData.length - 2].risk_score;
    return latest - previous;
  };

  const getRiskLevelColor = (level?: string) => {
    switch (level) {
      case 'low':
        return 'text-green-600 bg-green-100';
      case 'moderate':
        return 'text-yellow-600 bg-yellow-100';
      case 'high':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getAssessmentIcon = (type: string) => {
    switch (type) {
      case 'voice':
        return <Mic className="w-5 h-5" />;
      case 'face':
        return <Camera className="w-5 h-5" />;
      case 'typing':
        return <Keyboard className="w-5 h-5" />;
      default:
        return <Activity className="w-5 h-5" />;
    }
  };

  const latestScore = getLatestRiskScore();
  const trend = getRiskTrend();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Welcome back, {profile?.full_name || 'User'}
          </h1>
          <p className="text-gray-600">Monitor your health assessments and trends</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
                Latest Score
              </h3>
              <Activity className="w-5 h-5 text-blue-600" />
            </div>
            {latestScore !== null ? (
              <>
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  {latestScore}
                </div>
                <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${getRiskLevelColor(assessments[0]?.result?.risk_level)}`}>
                  {assessments[0]?.result?.risk_level?.toUpperCase()}
                </div>
              </>
            ) : (
              <div className="text-gray-400">No data yet</div>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
                Trend
              </h3>
              {trend !== null && (
                trend < 0 ? (
                  <TrendingDown className="w-5 h-5 text-green-600" />
                ) : (
                  <TrendingUp className="w-5 h-5 text-red-600" />
                )
              )}
            </div>
            {trend !== null ? (
              <>
                <div className={`text-4xl font-bold mb-2 ${trend < 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {trend > 0 ? '+' : ''}{trend.toFixed(1)}
                </div>
                <div className="text-sm text-gray-600">
                  {trend < 0 ? 'Improving' : 'Attention needed'}
                </div>
              </>
            ) : (
              <div className="text-gray-400">Not enough data</div>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-gray-600 uppercase tracking-wide">
                Assessments
              </h3>
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {assessments.length}
            </div>
            <div className="text-sm text-gray-600">Total completed</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <button
            onClick={() => onStartAssessment('voice')}
            className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] text-left"
          >
            <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
              <Mic className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Voice Analysis</h3>
            <p className="text-gray-600 text-sm">
              Record and analyze speech patterns for neurological indicators
            </p>
          </button>

          <button
            onClick={() => onStartAssessment('face')}
            className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] text-left"
          >
            <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
              <Camera className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Face Analysis</h3>
            <p className="text-gray-600 text-sm">
              Capture facial features and micro-expressions for analysis
            </p>
          </button>

          <button
            onClick={() => onStartAssessment('typing')}
            className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-200 transform hover:scale-[1.02] text-left"
          >
            <div className="bg-purple-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
              <Keyboard className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Typing Analysis</h3>
            <p className="text-gray-600 text-sm">
              Evaluate typing patterns and cognitive processing speed
            </p>
          </button>
        </div>

        {trendData.length > 0 && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Risk Score Trend</h3>
            <div className="flex items-end justify-between h-48 gap-2">
              {trendData.map((data, index) => (
                <div key={index} className="flex-1 flex flex-col items-center gap-2">
                  <div className="w-full bg-gray-100 rounded-t-lg relative" style={{ height: '100%' }}>
                    <div
                      className={`absolute bottom-0 w-full rounded-t-lg transition-all duration-500 ${
                        data.risk_score < 30 ? 'bg-green-500' :
                        data.risk_score < 70 ? 'bg-yellow-500' :
                        'bg-red-500'
                      }`}
                      style={{ height: `${data.risk_score}%` }}
                    >
                      <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-semibold text-gray-700">
                        {data.risk_score}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-600">{data.date.split('/')[1]}/{data.date.split('/')[0]}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gray-900">Recent Assessments</h3>
            <button
              onClick={onViewConsultations}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-semibold text-sm"
            >
              <Users className="w-4 h-4" />
              Consultations
            </button>
          </div>

          {loading ? (
            <div className="text-center py-12 text-gray-500">Loading assessments...</div>
          ) : assessments.length === 0 ? (
            <div className="text-center py-12">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">No assessments yet</p>
              <p className="text-sm text-gray-400">Start your first assessment above</p>
            </div>
          ) : (
            <div className="space-y-3">
              {assessments.map((assessment) => (
                <div
                  key={assessment.id}
                  className="border border-gray-200 rounded-xl p-4 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer"
                  onClick={() => onViewReport(assessment.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        {getAssessmentIcon(assessment.assessment_type)}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 capitalize">
                          {assessment.assessment_type} Analysis
                        </h4>
                        <div className="flex items-center gap-4 mt-1">
                          <span className="text-sm text-gray-600 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(assessment.completed_at!).toLocaleDateString()}
                          </span>
                          <span className="text-sm text-gray-600 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(assessment.completed_at!).toLocaleTimeString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {assessment.result && (
                        <>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-gray-900">
                              {assessment.result.risk_score}
                            </div>
                            <div className={`text-xs font-medium px-2 py-1 rounded-full ${getRiskLevelColor(assessment.result.risk_level)}`}>
                              {assessment.result.risk_level.toUpperCase()}
                            </div>
                          </div>
                          {assessment.result.risk_level === 'low' ? (
                            <CheckCircle className="w-6 h-6 text-green-600" />
                          ) : (
                            <AlertCircle className="w-6 h-6 text-yellow-600" />
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
