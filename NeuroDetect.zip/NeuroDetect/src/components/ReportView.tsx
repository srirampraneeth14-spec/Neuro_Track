import { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Activity,
  Mic,
  Camera,
  Keyboard,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Download,
  Share2,
  FileText,
  Calendar,
  Clock
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Assessment, AssessmentResult } from '../types';

interface ReportViewProps {
  assessmentId: string;
  onBack: () => void;
  onRequestConsultation: (assessmentId: string) => void;
}

export const ReportView = ({ assessmentId, onBack, onRequestConsultation }: ReportViewProps) => {
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAssessmentDetails();
  }, [assessmentId]);

  const fetchAssessmentDetails = async () => {
    setLoading(true);

    const { data: assessmentData, error: assessmentError } = await supabase
      .from('assessments')
      .select('*')
      .eq('id', assessmentId)
      .maybeSingle();

    if (assessmentError) {
      console.error('Error fetching assessment:', assessmentError);
      setLoading(false);
      return;
    }

    const { data: resultData, error: resultError } = await supabase
      .from('assessment_results')
      .select('*')
      .eq('assessment_id', assessmentId)
      .maybeSingle();

    if (resultError) {
      console.error('Error fetching result:', resultError);
    }

    setAssessment(assessmentData);
    setResult(resultData);
    setLoading(false);
  };

  const getRiskLevelColor = (level: string) => {
    switch (level) {
      case 'low':
        return 'text-green-600 bg-green-100 border-green-200';
      case 'moderate':
        return 'text-yellow-600 bg-yellow-100 border-yellow-200';
      case 'high':
        return 'text-red-600 bg-red-100 border-red-200';
      default:
        return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  const getRiskMessage = (level: string) => {
    switch (level) {
      case 'low':
        return 'Your assessment shows low risk indicators. Continue monitoring your health regularly.';
      case 'moderate':
        return 'Your assessment shows moderate risk indicators. Consider scheduling a follow-up assessment.';
      case 'high':
        return 'Your assessment shows elevated risk indicators. We strongly recommend consulting with a healthcare professional.';
      default:
        return '';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Activity className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading report...</p>
        </div>
      </div>
    );
  }

  if (!assessment || !result) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
          <p className="text-gray-600">Report not found</p>
          <button onClick={onBack} className="mt-4 text-blue-600 hover:text-blue-700">
            Go back
          </button>
        </div>
      </div>
    );
  }

  const getAssessmentIcon = () => {
    switch (assessment.assessment_type) {
      case 'voice':
        return <Mic className="w-6 h-6" />;
      case 'face':
        return <Camera className="w-6 h-6" />;
      case 'typing':
        return <Keyboard className="w-6 h-6" />;
      default:
        return <Activity className="w-6 h-6" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Dashboard
        </button>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="bg-blue-100 p-4 rounded-xl">
                {getAssessmentIcon()}
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900 capitalize">
                  {assessment.assessment_type} Analysis Report
                </h1>
                <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {new Date(assessment.completed_at!).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {new Date(assessment.completed_at!).toLocaleTimeString()}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                <Share2 className="w-5 h-5" />
              </button>
              <button className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
                <Download className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className={`border-2 rounded-2xl p-6 mb-8 ${getRiskLevelColor(result.risk_level)}`}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-sm font-semibold uppercase tracking-wide mb-2">
                  Risk Assessment
                </div>
                <div className="text-5xl font-bold">{result.risk_score}</div>
              </div>
              <div className="text-right">
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-lg font-bold ${getRiskLevelColor(result.risk_level)}`}>
                  {result.risk_level === 'low' ? (
                    <CheckCircle className="w-6 h-6" />
                  ) : (
                    <AlertCircle className="w-6 h-6" />
                  )}
                  {result.risk_level.toUpperCase()}
                </div>
              </div>
            </div>
            <p className="text-sm leading-relaxed">{getRiskMessage(result.risk_level)}</p>
          </div>

          {result.analysis_data && Object.keys(result.analysis_data).length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Detailed Analysis
              </h3>

              {result.analysis_data.voice && (
                <div className="bg-gray-50 rounded-xl p-6 mb-4">
                  <h4 className="font-semibold text-gray-900 mb-4">Voice Pattern Analysis</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Pitch Variation</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.voice.pitch_variation}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.voice.pitch_variation.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Speech Rate</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {result.analysis_data.voice.speech_rate.toFixed(0)} wpm
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Pause Frequency</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {result.analysis_data.voice.pause_frequency.toFixed(1)}/min
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Emotional Tone</div>
                      <div className="text-lg font-semibold text-gray-900 capitalize">
                        {result.analysis_data.voice.emotional_tone}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {result.analysis_data.face && (
                <div className="bg-gray-50 rounded-xl p-6 mb-4">
                  <h4 className="font-semibold text-gray-900 mb-4">Facial Feature Analysis</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Symmetry Score</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-green-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.face.symmetry_score}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.face.symmetry_score.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Micro-expressions</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-purple-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.face.micro_expressions}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.face.micro_expressions.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Eye Movement</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.face.eye_movement}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.face.eye_movement.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Facial Tension</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-yellow-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.face.facial_tension}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.face.facial_tension.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {result.analysis_data.typing && (
                <div className="bg-gray-50 rounded-xl p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Typing Pattern Analysis</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Average Speed</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {result.analysis_data.typing.average_speed.toFixed(0)} wpm
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Error Rate</div>
                      <div className="text-lg font-semibold text-gray-900">
                        {result.analysis_data.typing.error_rate.toFixed(1)}%
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Pause Patterns</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-blue-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.typing.pause_patterns}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.typing.pause_patterns.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-gray-600 mb-1">Rhythm Consistency</div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-green-600 h-full rounded-full"
                            style={{ width: `${result.analysis_data.typing.rhythm_consistency}%` }}
                          />
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.analysis_data.typing.rhythm_consistency.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {result.recommendations && result.recommendations.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Recommendations
              </h3>
              <div className="space-y-3">
                {result.recommendations.map((rec, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 bg-blue-50 border border-blue-200 rounded-lg p-4"
                  >
                    <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">{rec}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {result.risk_level !== 'low' && (
            <button
              onClick={() => onRequestConsultation(assessmentId)}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02]"
            >
              Request Doctor Consultation
            </button>
          )}
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6">
          <h3 className="font-semibold text-gray-900 mb-3">Important Notice</h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            This assessment is a screening tool powered by AI and should not be considered a
            medical diagnosis. Always consult with qualified healthcare professionals for proper
            medical evaluation and treatment. If you're experiencing symptoms or have health
            concerns, please seek medical attention immediately.
          </p>
        </div>
      </div>
    </div>
  );
};
