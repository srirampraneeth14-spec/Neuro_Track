import { useState } from 'react';
import { ShieldCheck, AlertCircle } from 'lucide-react';

interface ConsentFlowProps {
  onConsent: () => void;
  assessmentType: string;
}

export const ConsentFlow = ({ onConsent, assessmentType }: ConsentFlowProps) => {
  const [agreed, setAgreed] = useState(false);

  const getAssessmentDescription = () => {
    switch (assessmentType) {
      case 'voice':
        return 'record and analyze your voice patterns';
      case 'face':
        return 'capture and analyze your facial features';
      case 'typing':
        return 'analyze your typing patterns';
      default:
        return 'collect and analyze your health assessment data';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center justify-center mb-6">
          <div className="bg-blue-100 p-4 rounded-full">
            <ShieldCheck className="w-12 h-12 text-blue-600" />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-center mb-2 text-gray-900">
          Informed Consent
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Please review and accept the following terms before proceeding
        </p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6">
          <div className="flex items-start gap-3 mb-4">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">
                What We'll Collect
              </h3>
              <p className="text-gray-700 text-sm leading-relaxed">
                This assessment will {getAssessmentDescription()}. All data is processed using
                advanced AI algorithms to identify potential health indicators.
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4 mb-8">
          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-semibold text-gray-900 mb-1">Data Privacy</h4>
            <p className="text-sm text-gray-600">
              Your data is encrypted and stored securely. We never share your personal health
              information with third parties without your explicit consent.
            </p>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-semibold text-gray-900 mb-1">Medical Disclaimer</h4>
            <p className="text-sm text-gray-600">
              This assessment is a screening tool and does not replace professional medical
              diagnosis. Always consult qualified healthcare professionals for medical advice.
            </p>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-semibold text-gray-900 mb-1">Data Usage</h4>
            <p className="text-sm text-gray-600">
              Anonymized data may be used to improve our AI models and research. Individual
              identities are never disclosed.
            </p>
          </div>

          <div className="border-l-4 border-blue-500 pl-4">
            <h4 className="font-semibold text-gray-900 mb-1">Your Rights</h4>
            <p className="text-sm text-gray-600">
              You can withdraw consent and request deletion of your data at any time through
              your account settings.
            </p>
          </div>
        </div>

        <label className="flex items-start gap-3 mb-6 cursor-pointer group">
          <input
            type="checkbox"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            className="mt-1 w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-2 focus:ring-blue-500 cursor-pointer"
          />
          <span className="text-sm text-gray-700 leading-relaxed group-hover:text-gray-900 transition-colors">
            I have read and understood the above information. I consent to the collection and
            analysis of my data for health assessment purposes. I understand this is not a
            medical diagnosis and I should consult healthcare professionals for medical advice.
          </span>
        </label>

        <button
          onClick={onConsent}
          disabled={!agreed}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02] disabled:transform-none disabled:hover:scale-100"
        >
          {agreed ? 'Accept and Continue' : 'Please Accept Terms to Continue'}
        </button>

        <p className="text-center text-xs text-gray-500 mt-4">
          By continuing, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
};
