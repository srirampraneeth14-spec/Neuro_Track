import { useState, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Calendar,
  Clock,
  User,
  Send,
  FileText,
  CheckCircle,
  XCircle,
  AlertCircle,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Consultation, ConsultationMessage, Assessment } from '../types';

interface ConsultationsProps {
  onBack: () => void;
  preselectedAssessmentId?: string;
}

export const Consultations = ({ onBack, preselectedAssessmentId }: ConsultationsProps) => {
  const { user } = useAuth();
  const [view, setView] = useState<'list' | 'request' | 'chat'>('list');
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [selectedConsultation, setSelectedConsultation] = useState<Consultation | null>(null);
  const [messages, setMessages] = useState<ConsultationMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<string>(preselectedAssessmentId || '');
  const [requestNotes, setRequestNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      fetchConsultations();
      fetchAssessments();
    }
  }, [user]);

  useEffect(() => {
    if (preselectedAssessmentId) {
      setView('request');
      setSelectedAssessmentId(preselectedAssessmentId);
    }
  }, [preselectedAssessmentId]);

  useEffect(() => {
    if (selectedConsultation) {
      fetchMessages();
    }
  }, [selectedConsultation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const fetchConsultations = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('consultations')
      .select('*')
      .eq('user_id', user!.id)
      .order('created_at', { ascending: false });

    if (!error && data) {
      setConsultations(data);
    }
    setLoading(false);
  };

  const fetchAssessments = async () => {
    const { data, error } = await supabase
      .from('assessments')
      .select('*')
      .eq('user_id', user!.id)
      .eq('status', 'completed')
      .order('completed_at', { ascending: false })
      .limit(10);

    if (!error && data) {
      setAssessments(data);
    }
  };

  const fetchMessages = async () => {
    if (!selectedConsultation) return;

    const { data, error } = await supabase
      .from('consultation_messages')
      .select('*')
      .eq('consultation_id', selectedConsultation.id)
      .order('created_at', { ascending: true });

    if (!error && data) {
      setMessages(data);
    }
  };

  const handleRequestConsultation = async () => {
    if (!requestNotes.trim()) return;

    const { error } = await supabase.from('consultations').insert({
      user_id: user!.id,
      assessment_id: selectedAssessmentId || null,
      status: 'requested',
      notes: requestNotes,
      doctor_name: 'Dr. ' + ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones'][Math.floor(Math.random() * 5)],
      scheduled_at: new Date(Date.now() + Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString()
    });

    if (!error) {
      setRequestNotes('');
      setSelectedAssessmentId('');
      setView('list');
      fetchConsultations();
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConsultation) return;

    const { error } = await supabase.from('consultation_messages').insert({
      consultation_id: selectedConsultation.id,
      sender_id: user!.id,
      message: newMessage
    });

    if (!error) {
      setNewMessage('');
      fetchMessages();
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'requested':
        return 'text-blue-600 bg-blue-100';
      case 'scheduled':
        return 'text-green-600 bg-green-100';
      case 'completed':
        return 'text-gray-600 bg-gray-100';
      case 'cancelled':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'requested':
        return <Clock className="w-4 h-4" />;
      case 'scheduled':
        return <CheckCircle className="w-4 h-4" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4" />;
      case 'cancelled':
        return <XCircle className="w-4 h-4" />;
      default:
        return <AlertCircle className="w-4 h-4" />;
    }
  };

  if (view === 'request') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-2xl mx-auto px-4 py-8">
          <button
            onClick={() => setView('list')}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Consultations
          </button>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Request Consultation
            </h2>

            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Related Assessment (Optional)
              </label>
              <select
                value={selectedAssessmentId}
                onChange={(e) => setSelectedAssessmentId(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
              >
                <option value="">None - General consultation</option>
                {assessments.map((assessment) => (
                  <option key={assessment.id} value={assessment.id}>
                    {assessment.assessment_type.charAt(0).toUpperCase() + assessment.assessment_type.slice(1)} Assessment -{' '}
                    {new Date(assessment.completed_at!).toLocaleDateString()}
                  </option>
                ))}
              </select>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Reason for Consultation
              </label>
              <textarea
                value={requestNotes}
                onChange={(e) => setRequestNotes(e.target.value)}
                placeholder="Please describe your concerns or questions for the doctor..."
                rows={6}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all resize-none"
              />
            </div>

            <button
              onClick={handleRequestConsultation}
              disabled={!requestNotes.trim()}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02] disabled:transform-none"
            >
              Submit Request
            </button>

            <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-gray-700">
                A doctor will review your request and schedule a consultation within 24-48 hours.
                You will receive a notification once your consultation is scheduled.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (view === 'chat' && selectedConsultation) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <button
            onClick={() => {
              setView('list');
              setSelectedConsultation(null);
            }}
            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Consultations
          </button>

          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-6 text-white">
              <div className="flex items-center gap-3 mb-2">
                <div className="bg-white/20 p-2 rounded-lg">
                  <User className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{selectedConsultation.doctor_name || 'Doctor'}</h2>
                  <div className="flex items-center gap-2 text-blue-100 text-sm">
                    <Calendar className="w-4 h-4" />
                    {selectedConsultation.scheduled_at
                      ? new Date(selectedConsultation.scheduled_at).toLocaleString()
                      : 'Not scheduled yet'}
                  </div>
                </div>
              </div>
              <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(selectedConsultation.status)}`}>
                {getStatusIcon(selectedConsultation.status)}
                {selectedConsultation.status.toUpperCase()}
              </div>
            </div>

            <div className="h-96 overflow-y-auto p-6 bg-gray-50">
              {messages.length === 0 ? (
                <div className="text-center text-gray-500 mt-20">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>No messages yet. Start the conversation!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender_id === user!.id ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                          message.sender_id === user!.id
                            ? 'bg-blue-600 text-white'
                            : 'bg-white text-gray-900 border border-gray-200'
                        }`}
                      >
                        <p className="text-sm">{message.message}</p>
                        <p className={`text-xs mt-1 ${message.sender_id === user!.id ? 'text-blue-100' : 'text-gray-500'}`}>
                          {new Date(message.created_at).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            <div className="p-4 bg-white border-t border-gray-200">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!newMessage.trim()}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white p-3 rounded-lg transition-colors"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Dashboard
        </button>

        <div className="flex items-center justify-between mb-8">
          <h1 className="text-4xl font-bold text-gray-900">Consultations</h1>
          <button
            onClick={() => setView('request')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg transition-colors flex items-center gap-2"
          >
            <Calendar className="w-5 h-5" />
            Request Consultation
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-6">
          {loading ? (
            <div className="text-center py-12 text-gray-500">Loading consultations...</div>
          ) : consultations.length === 0 ? (
            <div className="text-center py-12">
              <User className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 mb-4">No consultations yet</p>
              <button
                onClick={() => setView('request')}
                className="text-blue-600 hover:text-blue-700 font-semibold"
              >
                Request your first consultation
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {consultations.map((consultation) => (
                <div
                  key={consultation.id}
                  className="border border-gray-200 rounded-xl p-5 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer"
                  onClick={() => {
                    setSelectedConsultation(consultation);
                    setView('chat');
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-100 p-3 rounded-lg">
                        <User className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg">
                          {consultation.doctor_name || 'Doctor TBD'}
                        </h3>
                        <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {consultation.scheduled_at
                              ? new Date(consultation.scheduled_at).toLocaleDateString()
                              : 'Not scheduled'}
                          </span>
                          {consultation.scheduled_at && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(consultation.scheduled_at).toLocaleTimeString()}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(consultation.status)}`}>
                      {getStatusIcon(consultation.status)}
                      {consultation.status.toUpperCase()}
                    </div>
                  </div>

                  {consultation.notes && (
                    <div className="bg-gray-50 rounded-lg p-3 mb-3">
                      <p className="text-sm text-gray-700 line-clamp-2">{consultation.notes}</p>
                    </div>
                  )}

                  {consultation.assessment_id && (
                    <div className="flex items-center gap-2 text-sm text-blue-600">
                      <FileText className="w-4 h-4" />
                      <span>Related to assessment</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
