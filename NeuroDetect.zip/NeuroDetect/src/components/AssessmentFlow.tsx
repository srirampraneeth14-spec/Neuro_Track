import { useState } from 'react';
import { ConsentFlow } from './ConsentFlow';
import { VoiceAnalysis } from './VoiceAnalysis';
import { FaceAnalysis } from './FaceAnalysis';
import { TypingAnalysis } from './TypingAnalysis';
import { Loader2, CheckCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { generateMockAnalysis, simulateProcessingDelay } from '../utils/mockAI';
import { AssessmentType } from '../types';

interface AssessmentFlowProps {
  assessmentType: AssessmentType;
  onComplete: () => void;
}

export const AssessmentFlow = ({ assessmentType, onComplete }: AssessmentFlowProps) => {
  const { user } = useAuth();
  const [step, setStep] = useState<'consent' | 'capture' | 'processing' | 'complete'>('consent');
  const [assessmentId, setAssessmentId] = useState<string>('');

  const handleConsent = async () => {
    const { data, error } = await supabase
      .from('assessments')
      .insert({
        user_id: user!.id,
        assessment_type: assessmentType,
        consent_given: true,
        status: 'in_progress'
      })
      .select()
      .single();

    if (!error && data) {
      setAssessmentId(data.id);
      setStep('capture');
    }
  };

  const handleCaptureComplete = async (captureData?: any) => {
    setStep('processing');

    if (assessmentType === 'voice' && captureData) {
      await supabase.from('voice_recordings').insert({
        assessment_id: assessmentId,
        duration_seconds: captureData,
        audio_features: {
          sample_rate: 44100,
          channels: 1
        }
      });
    } else if (assessmentType === 'face') {
      await supabase.from('face_captures').insert({
        assessment_id: assessmentId,
        facial_features: {
          landmarks: 68,
          captured_at: new Date().toISOString()
        }
      });
    } else if (assessmentType === 'typing' && captureData) {
      await supabase.from('typing_patterns').insert({
        assessment_id: assessmentId,
        keystroke_data: captureData,
        text_sample: 'Sample text'
      });
    }

    await simulateProcessingDelay(3);

    const analysisResult = generateMockAnalysis(assessmentType);

    await supabase.from('assessment_results').insert({
      assessment_id: assessmentId,
      risk_score: analysisResult.risk_score,
      risk_level: analysisResult.risk_level,
      analysis_data: analysisResult.analysis_data,
      recommendations: analysisResult.recommendations
    });

    await supabase
      .from('assessments')
      .update({
        status: 'completed',
        completed_at: new Date().toISOString()
      })
      .eq('id', assessmentId);

    setStep('complete');

    setTimeout(() => {
      onComplete();
    }, 2000);
  };

  if (step === 'consent') {
    return <ConsentFlow onConsent={handleConsent} assessmentType={assessmentType} />;
  }

  if (step === 'capture') {
    if (assessmentType === 'voice') {
      return <VoiceAnalysis onComplete={handleCaptureComplete} />;
    }
    if (assessmentType === 'face') {
      return <FaceAnalysis onComplete={handleCaptureComplete} />;
    }
    if (assessmentType === 'typing') {
      return <TypingAnalysis onComplete={handleCaptureComplete} />;
    }
  }

  if (step === 'processing') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <Loader2 className="w-16 h-16 text-blue-600 animate-spin mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-900 mb-3">
            Analyzing Your Data
          </h2>
          <p className="text-gray-600 mb-6">
            Our AI is processing your {assessmentType} patterns to generate insights...
          </p>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-gray-700">
              This typically takes a few seconds. Please wait while we analyze your data.
            </p>
          </div>
        </div>
      </div>
    );
  }

  if (step === 'complete') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-900 mb-3">
            Assessment Complete!
          </h2>
          <p className="text-gray-600">
            Your results are ready. Redirecting to dashboard...
          </p>
        </div>
      </div>
    );
  }

  return null;
};
