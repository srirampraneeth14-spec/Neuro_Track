import { useState, useRef, useEffect } from 'react';
import { Mic, Square, Loader2, CheckCircle } from 'lucide-react';

interface VoiceAnalysisProps {
  onComplete: (duration: number) => void;
}

export const VoiceAnalysis = ({ onComplete }: VoiceAnalysisProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const intervalRef = useRef<number>();
  const audioContextRef = useRef<AudioContext>();
  const analyserRef = useRef<AnalyserNode>();
  const animationRef = useRef<number>();

  const minRecordingTime = 10;

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const audioContext = new AudioContext();
      const analyser = audioContext.createAnalyser();
      const microphone = audioContext.createMediaStreamSource(stream);

      analyser.fftSize = 256;
      microphone.connect(analyser);

      audioContextRef.current = audioContext;
      analyserRef.current = analyser;

      setIsRecording(true);
      setRecordingTime(0);

      intervalRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

      const updateAudioLevel = () => {
        if (analyserRef.current) {
          const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
          analyserRef.current.getByteFrequencyData(dataArray);
          const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
          setAudioLevel(average / 255);
        }
        animationRef.current = requestAnimationFrame(updateAudioLevel);
      };
      updateAudioLevel();

    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please grant permission and try again.');
    }
  };

  const stopRecording = async () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (animationRef.current) cancelAnimationFrame(animationRef.current);
    if (audioContextRef.current) audioContextRef.current.close();

    setIsRecording(false);
    setIsProcessing(true);

    await new Promise(resolve => setTimeout(resolve, 2000));

    setIsProcessing(false);
    setIsComplete(true);

    setTimeout(() => {
      onComplete(recordingTime);
    }, 1000);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
        <h2 className="text-3xl font-bold text-center mb-2 text-gray-900">
          Voice Analysis
        </h2>
        <p className="text-center text-gray-600 mb-8">
          Read the following passage clearly and naturally
        </p>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-8">
          <p className="text-gray-800 leading-relaxed text-lg">
            "The quick brown fox jumps over the lazy dog. Technology has transformed the way we
            communicate and interact with the world around us. Every day brings new opportunities
            to learn, grow, and connect with others."
          </p>
        </div>

        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-6">
            <div
              className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-300 ${
                isRecording
                  ? 'bg-red-500 shadow-lg shadow-red-500/50'
                  : isComplete
                  ? 'bg-green-500 shadow-lg shadow-green-500/50'
                  : 'bg-blue-500 shadow-lg shadow-blue-500/50'
              }`}
              style={{
                transform: isRecording ? `scale(${1 + audioLevel * 0.3})` : 'scale(1)',
              }}
            >
              {isProcessing ? (
                <Loader2 className="w-12 h-12 text-white animate-spin" />
              ) : isComplete ? (
                <CheckCircle className="w-12 h-12 text-white" />
              ) : isRecording ? (
                <Square className="w-12 h-12 text-white" />
              ) : (
                <Mic className="w-12 h-12 text-white" />
              )}
            </div>
            {isRecording && (
              <div className="absolute inset-0 rounded-full animate-ping bg-red-500 opacity-20"></div>
            )}
          </div>

          <div className="text-4xl font-bold text-gray-900 mb-2">
            {formatTime(recordingTime)}
          </div>

          {isRecording && recordingTime < minRecordingTime && (
            <p className="text-sm text-gray-600 mb-4">
              Please record for at least {minRecordingTime} seconds
            </p>
          )}

          {isProcessing && (
            <p className="text-sm text-blue-600 mb-4">
              Analyzing voice patterns...
            </p>
          )}

          {isComplete && (
            <p className="text-sm text-green-600 mb-4">
              Recording complete!
            </p>
          )}
        </div>

        {!isRecording && !isProcessing && !isComplete && (
          <button
            onClick={startRecording}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02]"
          >
            Start Recording
          </button>
        )}

        {isRecording && (
          <button
            onClick={stopRecording}
            disabled={recordingTime < minRecordingTime}
            className="w-full bg-red-600 hover:bg-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-all duration-200 transform hover:scale-[1.02] disabled:transform-none"
          >
            {recordingTime < minRecordingTime
              ? `Continue recording (${minRecordingTime - recordingTime}s remaining)`
              : 'Stop Recording'}
          </button>
        )}

        <div className="mt-6 bg-gray-50 rounded-lg p-4">
          <h4 className="font-semibold text-gray-900 mb-2 text-sm">Tips for best results:</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• Speak in a quiet environment</li>
            <li>• Use your natural speaking voice</li>
            <li>• Read the passage at a comfortable pace</li>
            <li>• Ensure your microphone is working properly</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
