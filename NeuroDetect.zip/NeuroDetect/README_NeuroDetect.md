# 🧠 NeuroDetect AI — Full-Stack Cognitive Assessment Platform

NeuroDetect AI is a full-stack web application that uses React (Vite) on the frontend and Flask + OpenCV on the backend to perform cognitive tests and generate user reports.

---

## 🚀 Quick Start Guide

### 1️⃣ Clone or Extract Project
Extract the **NeuroDetect.zip** file to your local machine.

```bash
cd NeuroDetect
```
### 2️⃣ 
npm install
npm run dev
```

---

© 2025 NeuroDetect AI — Cognitive Intelligence Simplified.
