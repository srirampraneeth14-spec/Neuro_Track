/*
  # NeuroDetect AI Database Schema

  ## Overview
  Complete database schema for NeuroDetect AI health assessment platform with user profiles,
  assessment data, AI analysis results, and doctor consultation features.

  ## New Tables

  ### 1. `profiles`
  User profile information linked to auth.users
  - `id` (uuid, primary key) - References auth.users
  - `full_name` (text) - User's full name
  - `date_of_birth` (date) - Date of birth for age calculations
  - `phone` (text) - Contact phone number
  - `emergency_contact` (text) - Emergency contact information
  - `medical_history` (jsonb) - Structured medical history data
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last profile update

  ### 2. `assessments`
  Main assessment records for each screening session
  - `id` (uuid, primary key) - Unique assessment identifier
  - `user_id` (uuid, foreign key) - References profiles(id)
  - `assessment_type` (text) - Type: 'voice', 'face', 'typing', or 'combined'
  - `status` (text) - Status: 'in_progress', 'completed', 'failed'
  - `consent_given` (boolean) - User consent confirmation
  - `started_at` (timestamptz) - Assessment start time
  - `completed_at` (timestamptz) - Assessment completion time
  - `created_at` (timestamptz) - Record creation timestamp

  ### 3. `assessment_results`
  AI analysis results and risk scores for each assessment
  - `id` (uuid, primary key) - Unique result identifier
  - `assessment_id` (uuid, foreign key) - References assessments(id)
  - `risk_score` (integer) - Overall risk score (0-100)
  - `risk_level` (text) - Risk category: 'low', 'moderate', 'high'
  - `analysis_data` (jsonb) - Detailed AI analysis metrics
  - `recommendations` (text[]) - Array of recommendation strings
  - `created_at` (timestamptz) - Result creation timestamp

  ### 4. `voice_recordings`
  Voice analysis data storage
  - `id` (uuid, primary key) - Unique recording identifier
  - `assessment_id` (uuid, foreign key) - References assessments(id)
  - `duration_seconds` (integer) - Recording duration
  - `audio_features` (jsonb) - Extracted audio features (pitch, tempo, etc.)
  - `created_at` (timestamptz) - Recording timestamp

  ### 5. `face_captures`
  Facial analysis data storage
  - `id` (uuid, primary key) - Unique capture identifier
  - `assessment_id` (uuid, foreign key) - References assessments(id)
  - `facial_features` (jsonb) - Extracted facial feature metrics
  - `created_at` (timestamptz) - Capture timestamp

  ### 6. `typing_patterns`
  Typing pattern analysis data
  - `id` (uuid, primary key) - Unique pattern identifier
  - `assessment_id` (uuid, foreign key) - References assessments(id)
  - `keystroke_data` (jsonb) - Timing and pattern data
  - `text_sample` (text) - Anonymized text sample
  - `created_at` (timestamptz) - Pattern capture timestamp

  ### 7. `consultations`
  Doctor consultation requests and scheduling
  - `id` (uuid, primary key) - Unique consultation identifier
  - `user_id` (uuid, foreign key) - References profiles(id)
  - `assessment_id` (uuid, foreign key) - References assessments(id), nullable
  - `status` (text) - Status: 'requested', 'scheduled', 'completed', 'cancelled'
  - `scheduled_at` (timestamptz) - Scheduled consultation time
  - `doctor_name` (text) - Assigned doctor name
  - `notes` (text) - Consultation notes
  - `created_at` (timestamptz) - Request creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 8. `consultation_messages`
  Messaging between users and doctors
  - `id` (uuid, primary key) - Unique message identifier
  - `consultation_id` (uuid, foreign key) - References consultations(id)
  - `sender_id` (uuid, foreign key) - References profiles(id)
  - `message` (text) - Message content
  - `created_at` (timestamptz) - Message timestamp

  ## Security

  ### Row Level Security (RLS)
  All tables have RLS enabled with restrictive policies ensuring:
  - Users can only access their own data
  - Authenticated access is required for all operations
  - Proper ownership checks on all queries

  ### Policies
  Separate policies for SELECT, INSERT, UPDATE, and DELETE operations
  - SELECT: Users can view their own records
  - INSERT: Users can create their own records
  - UPDATE: Users can update their own records
  - DELETE: Users can delete their own records (where applicable)

  ## Notes
  1. All timestamps use `timestamptz` for proper timezone handling
  2. JSONB fields allow flexible storage of complex analysis data
  3. Foreign key constraints ensure data integrity
  4. Default values prevent null issues on critical fields
  5. Indexes on foreign keys optimize query performance
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  date_of_birth date,
  phone text,
  emergency_contact text,
  medical_history jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Create assessments table
CREATE TABLE IF NOT EXISTS assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  assessment_type text NOT NULL,
  status text DEFAULT 'in_progress',
  consent_given boolean DEFAULT false,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own assessments"
  ON assessments FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own assessments"
  ON assessments FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own assessments"
  ON assessments FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own assessments"
  ON assessments FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());

-- Create assessment_results table
CREATE TABLE IF NOT EXISTS assessment_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  risk_score integer NOT NULL,
  risk_level text NOT NULL,
  analysis_data jsonb DEFAULT '{}'::jsonb,
  recommendations text[] DEFAULT ARRAY[]::text[],
  created_at timestamptz DEFAULT now()
);

ALTER TABLE assessment_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own assessment results"
  ON assessment_results FOR SELECT
  TO authenticated
  USING (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own assessment results"
  ON assessment_results FOR INSERT
  TO authenticated
  WITH CHECK (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

-- Create voice_recordings table
CREATE TABLE IF NOT EXISTS voice_recordings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  duration_seconds integer NOT NULL,
  audio_features jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE voice_recordings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own voice recordings"
  ON voice_recordings FOR SELECT
  TO authenticated
  USING (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own voice recordings"
  ON voice_recordings FOR INSERT
  TO authenticated
  WITH CHECK (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

-- Create face_captures table
CREATE TABLE IF NOT EXISTS face_captures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  facial_features jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE face_captures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own face captures"
  ON face_captures FOR SELECT
  TO authenticated
  USING (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own face captures"
  ON face_captures FOR INSERT
  TO authenticated
  WITH CHECK (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

-- Create typing_patterns table
CREATE TABLE IF NOT EXISTS typing_patterns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  assessment_id uuid NOT NULL REFERENCES assessments(id) ON DELETE CASCADE,
  keystroke_data jsonb DEFAULT '{}'::jsonb,
  text_sample text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE typing_patterns ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own typing patterns"
  ON typing_patterns FOR SELECT
  TO authenticated
  USING (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own typing patterns"
  ON typing_patterns FOR INSERT
  TO authenticated
  WITH CHECK (
    assessment_id IN (
      SELECT id FROM assessments WHERE user_id = auth.uid()
    )
  );

-- Create consultations table
CREATE TABLE IF NOT EXISTS consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  assessment_id uuid REFERENCES assessments(id) ON DELETE SET NULL,
  status text DEFAULT 'requested',
  scheduled_at timestamptz,
  doctor_name text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE consultations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own consultations"
  ON consultations FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own consultations"
  ON consultations FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own consultations"
  ON consultations FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Create consultation_messages table
CREATE TABLE IF NOT EXISTS consultation_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  consultation_id uuid NOT NULL REFERENCES consultations(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE consultation_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view messages from own consultations"
  ON consultation_messages FOR SELECT
  TO authenticated
  USING (
    consultation_id IN (
      SELECT id FROM consultations WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert messages to own consultations"
  ON consultation_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = auth.uid() AND
    consultation_id IN (
      SELECT id FROM consultations WHERE user_id = auth.uid()
    )
  );

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_assessments_user_id ON assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_assessment_results_assessment_id ON assessment_results(assessment_id);
CREATE INDEX IF NOT EXISTS idx_consultations_user_id ON consultations(user_id);
CREATE INDEX IF NOT EXISTS idx_consultation_messages_consultation_id ON consultation_messages(consultation_id);